# Naruto Generations — a ninja mod for Minecraft Forge 1.20.1

Chakra, releases and jutsu, levels and stats, Ryo, and ninja tools.

## Building the jar

**With GitHub (no Java needed):** upload `Naruto Generations.zip` (still zipped) to your repository, after
deleting the old zip (the workflow builds every zip it finds). The "Build mod jar" workflow runs on its own. When it's green, download **shinobiarts-jar**,
unzip it, and put `Naruto Generations-1.8.1.jar` in your profile's `mods` folder (remove any older copy of the mod
first: two copies of the mod crash the game).

**On your PC:** install JDK 17, open a terminal in this folder and run `gradlew build`
(`./gradlew build` on Mac/Linux). The jar appears in `build/libs/`.

## What's new in 1.9.0

- **Edo Tensei** (new S-rank jutsu, from its scroll): Impure World Reincarnation. It brings back the souls of the
  ninja you killed most recently (up to 2 per cast; the last 5 you killed are remembered), in bodies of ash and dust:
  - **A living sacrifice for each soul:** an ordinary mob near you (never players, pets, named mobs or bosses) is
    wrapped in flakes of dust until nothing's left, and the dust streams to a spot in front of you.
  - **The coffin** (the "Naruto - Ataud Edo Tensei" model by GremorySaiyan, CC BY 4.0): it comes up out of the
    ground there, its sealed lid tips forward and slams flat, and the soul
    steps out wearing the dead player's own skin (fetched like a player head's, so it works when they're offline),
    cracked like dry clay from head to feet (over their clothes too), with the whites of its eyes gone black. Then the coffin sinks away. The dead
    player gets a message that their soul was called back.
  - **It can't be killed.** What would kill it only breaks it apart: its head and limbs fall away to dust and drift
    back one by one, and a few seconds later it's whole again. It fights whatever you fight, leaps at targets,
    hits harder the higher the soul's level was, and keeps up with you.
  - **Release (Kai):** right-click one of your souls, or cast the jutsu again, and the soul goes back up as a pale
    light while the body crumbles to dust. They're also released after 90 seconds, or if you die or leave.
  - With nobody to call back, a nameless shinobi answers, in one of three skins made for the mod (a cloaked
    wanderer, a village guard, a swordsman). Time, souls per cast, health, damage and whether a
    sacrifice is needed are in the config (`edoTensei...`).
- **The Kamui dimension** (Obito's): the Mangekyou designs with Kamui get two new eye techniques:
  - **Kamui Warp** (Jutsu 1): you're twisted into a spiral and sucked into your eye, and come out in the Kamui
    dimension: an endless void with no sky and no daylight, dim all the time but lit by hidden light blocks on every
    pillar top and along the floor so you can see where you're standing, filled with a
    grid of huge square light blue terracotta pillars of different heights. It's generated with the world, chunk by chunk,
    so it goes on forever in every direction. Use it again to come back to exactly where you left.
  - **Kamui Abduction** (Sneak + Jutsu 1): whoever you're looking at (up to 24 blocks) twists into a spiral and is
    pulled in. Mobs are stuck there; players are let out where they were taken after 30 seconds. Bosses and creative players can't be taken.
- **Ninja tools:**
  - **Smoke Bomb:** throw it and it bursts into a thick grey cloud that hides everyone in it (blinds whoever's
    inside, and mobs lose track of their targets).
  - **Wire Trap:** right-click a block, then another up to 12 blocks away, to string a steel wire between them.
    Whoever runs into it is wound up in it and held for 3 seconds. Hit the wire to cut it.
  - **Explosive Tag Kunai:** a thrown kunai with a tag on it: it sticks where it lands, the tag fizzes, and it goes
    off a moment and a half later.
  - All three can be crafted (see JEI or the recipe book).
- **Bounty board:** a new **Bounties** page in the ninja menu shows a wanted poster for everyone with a price on
  their head: their face, name, bounty, level and rank, village, clan, kills/deaths and best streak, and whether
  they're online. Put a bounty on someone right there (their name and the Ryo, then Post; or `/bounty <player>
  <ryo>`, at least 500). Whoever kills them with a rewarded kill takes the whole pot. `/bounty list` too.
- **PvP leaderboard:** `/shinobi lb` (or `/shinobi lb kills|kd|streak|bounty`) lists the top 10 and your place.
  Kill streaks of 5, 10, 15... are announced.

- **Flying Thunder God Technique.** The new **Flying Thunder God Kunai** (Minato's three-pronged kunai; craft it from
  a kunai, ender pearl, gold ingot, ink sac and paper) marks places, and you flash to any mark in an instant:
  - **Right-click a block** with it to write the seal formula on that face (sneak + right-click to wipe it off).
    Only you see your seals.
  - **Throw it** (right-click into the air): it sticks where it lands and is a mark while it's there. Flash to it
    and you catch it again.
  - **Hit someone** with it (thrown or in melee) and they carry your mark for 2 minutes; flashing to them puts you
    right behind them.
  - **Teleport** by right-clicking toward a mark while holding the kunai (a yellow ring shows which one you're
    aiming at), or from the new **Marks** page of the ninja menu: every mark with how far away it is, and Go, Name
    (give it your own name, Enter to save) and Delete buttons. Each flash costs 5% chakra and leaves a yellow flash where you vanish and where you appear.
  - **No teleporting while in combat** (the 60-second combat tag from hitting or being hit by another player): the
    Go buttons grey out and right-clicking toward a mark just tells you how long is left. Marking still works.
  - Up to 12 marks at once (the oldest fades). Range, cost, cooldown, how long people stay marked, whether you can
    flash to another dimension and the lowest rank that can use it are in the `flyingThunderGod` config section.
- **Tengai Shinsei** (new Rinnegan jutsu, S rank): Madara's meteor. Pull a huge burning rock out of the sky onto where
  you look (up to 64 blocks). Its shadow spreads over the ground and the sky rumbles for 3.5 seconds, then it lands
  in a huge blast: a white flash, a fireball, a dome of dust, shockwaves and rubble flying (damage falls off toward
  the edge; you aren't hurt by your own). Then a second, bigger meteor follows. Every Rinnegan user learns it. Damage,
  the second meteor and craters (off by default, so it doesn't wreck builds) are in the config.
- **Quest rewards include jutsu scrolls.** Every random quest pays out a scroll too, shown on the board in its rank's
  colour: hourly quests a D-rank scroll, daily a C or B (10% chance of an A, 3% of an S), weekly a B (30% A, 12% S),
  monthly an A (40% S). The chances are in General.toml (`questScrolls`, `dailyScrollChanceA`, ...).
- **Flying Thunder God takes people along:** anyone crouching within 2.5 blocks of you when you flash is taken with
  you (set down around you), unless they're in combat.
- **Stealing a Sharingan is now a 2% chance** on a rewarded PvP kill instead of every time (`eyeTheftChance`).
- **Jutsu scrolls and releases can't be crafted any more.** Releases are still handed over when you unlock a nature
  or kekkei genkai; hand out jutsu scrolls however you like (the shop's stock list can sell them, or `/give`).
- **Jinchuriki.** Seal a tailed beast into a player with `/jinchuriki give <player> <beast>` (a name like `kurama`
  or a tail count like `9`; `/jinchuriki remove <player>` and `/jinchuriki info <player>` too, ops only). One
  holder per beast by default. Press **M** to let its chakra out:
  - **Rage forms (1 to 6 tails):** the beast's chakra boils out over you as a shroud with its ears or horns,
    glowing white eyes that blink, and as many swaying chakra tails as the form has (from 4 tails it turns dark and
    thick). **You can't
    control your body:** the beast turns you toward the nearest creature (friend or foe), runs it down, leaps after
    it and tears into it, and from 4 tails it roars everything back. Your keys and clicks do nothing until it burns
    out, and it leaves you slowed and weakened.
  - **EXP:** time spent in your highest form earns EXP toward the next: 400 for 2 tails, 600 for 3, then 200 more
    for each (all set in the config). The bar at the top of the screen shows it.
  - **Chakra cloak:** after the last rage form, the beast is tamed. Its cloak is bright in its own colour, with dark
    swirling markings, every one of its tails and eyes of its colour, and it's under your control: strength,
    speed, healing, jumping, and **right-click with an empty hand fires a Tailed Beast Bomb** (black and white
    chakra gathered in front of you, then fired where you look, bursting in a dome). Press M again to let it go.
- **Every Byakugan move reworked with new models, to look like the show:**
  - **The Byakugan:** veins bulge out from the corners of the eyes toward the temples and up the bridge of the
    nose, and rings of sight pulse out when it switches on.
  - **Gentle Fist:** each punch lands as a palm of chakra, with the chakra pathways lighting up inside the target.
  - **Eight Trigrams 64 Palms:** the Eight Trigrams field (the trigrams round the yin-yang) spreads across the
    ground under you both, then the palms land in doublings, each called out: 2, 4, 8, 16, 32, 64. They're palms of
    chakra flashing onto the target's chakra points from every angle, faster each time, with the target held in
    place. The 64th drives them back, and their chakra stays sealed.
  - **Air Palm:** a ghostly palm of pressure flies out inside a ripple of rings and bursts where it lands (the
    damage now lands when it arrives).
  - **Eight Trigrams Palm Rotation:** a whirling dome of streaked chakra round you, a bright band where it meets the
    ground and a groove cut into it. You spin inside it, fast at first and slowing as it ends.
  - **All-Seeing Eye:** a sphere of fine lines spreads out to its range.
  - **X-ray sight:** while the Byakugan is on, everything alive within 32 blocks shows through walls as its
    chakra network (only you see it, even invisible creatures). Blue pathways run from the chakra centre to the
    head, arms and legs, dotted with tenketsu points, with chakra pulsing along them. Like in the show, it has one
    blind spot: a narrow cone straight behind your neck. The All-Seeing Eye stretches it much farther.
- **Four new kekkei genkai: the advanced natures.** They're two elements at once, and no clan is born with them.
  Awaken them from DNA (mob and player drops) to get the release and all its jutsu:
  - **Lava Release** (Fire + Earth): Scorching Stream Rock (a volley of molten rocks), Quicklime Congealing
    (quicklime that sets solid and traps whoever it hits) and Melting Apparition (a flood of corrosive lava).
  - **Storm Release** (Lightning + Water): Laser Circus (bending beams that chase everyone in front) and Storm
    Cloud (a black cloud that rains beams of storm chakra for six seconds).
  - **Boil Release** (Fire + Water): Skilled Mist (a corrosive mist that melts skin and armour) and Unrivalled
    Strength (20 seconds of boiling power; every punch bursts with scalding steam).
  - **Scorch Release** (Fire + Wind): Scorching Sun (a little sun that dries out what it hits) and Extremely
    Steaming Murder (five suns circle you and fly at the nearest enemies one by one).

## What's new in 1.8.1

- **Susanoo burn like in the show:** flickering tongues of chakra flame in the Susanoo's own colour lick up off its
  whole outline (tallest off the shoulders, head and arms), the flames round its base and in its mane sway and
  flicker, and embers of its colour rise all over it.
- **Weapons in the show's colours:** Itachi's Totsuka Sword and Yata Mirror red-orange, Sasuke's sword and bow
  purple, Madara's swords blue (Obito's Kamui shuriken stay black). Colours from `/susanoo color` presets now give
  the weapons a lighter shade of the body too, instead of white.

## What's new in 1.8.0

- **Every Susanoo is its owner's own, like in the show** (Humanoid, Armored and Perfect):
  - **Itachi:** the Totsuka Sword (a long, wavering blade of spirit pouring out of a sake gourd held in the right
    hand) and the Yata Mirror (a great eight-sided mirror with three magatama) in the left, raised before the face
    to block. Red.
  - **Sasuke:** a katana in the right hand and a great bow of chakra in the left. Its special draws the bow and
    looses a homing arrow of chakra that bursts on impact. Purple.
  - **Obito:** a Kamui shuriken in each hand, shaped like your picture. Its special throws them (at every stage, not
    just the Perfect Susanoo); the thrown ones are a bit smaller now. Cyan.
  - **Madara (Eternal Mangekyou):** twin katanas, cutting with each in turn and both together, and the Perfect
    Susanoo has a second face on the back of its head. Blue.
  - Each design's colours are its default until you pick your own with `/susanoo color`.
- **Hands that hold their weapons:** every hand points on along its forearm and closes round its weapon's grip
  (the hilt, the gourd's neck, the bow's grip, the shuriken's blade), and the wrists turn with every cut, draw,
  throw and block. The Skeletal Susanoo's claws point the right way too.
- **A real flight animation:** the Perfect Susanoo leans into the flight (up to 50 degrees at full speed, tipping
  back as it climbs), banks into turns, trails its legs with the knees bent, holds its weapons forward, and beats
  its wings: deep and quick while hovering or climbing, slow and shallow in a fast glide. It pivots on its head, so
  you stay inside it.
- **No more getting stuck on buildings:** flying into one, it climbs up and over it.

## What's new in 1.7.0

- **14 new jutsu:**
  - Fire: **Great Dragon Fire Technique** (A).
  - Water: **Hiding in Mist** (C).
  - Wind: **Vacuum Sphere** (C), **Vacuum Great Sphere** (A), **Vacuum Great Sickle Weasel** (A).
  - Lightning: **Kirin** (S), **Black Panther** (A), **False Darkness** (B), **Lightning Beast Running Technique** (B).
  - Earth: **Earth Spear** (B), **Hiding Like a Mole** (C), **Earth Dragon Bullet** (B), **Earth Sandwich** (A),
    **Rock Golem** (S).
  - Lightning Armor is now called **Lightning Release Chakra Mode**. Vacuum Blade was already in.
- **The Rinnegan is a release and a dojutsu:**
  - Its three jutsu live on the new **Rinnegan Release** (with your picture as its emblem). Anyone with the Rinnegan
    gets the release item automatically.
  - Press **C** to switch the Rinnegan on and off like the Sharingan and Byakugan. While it's on you get Resistance
    and Strength, and its jutsu do 25% more damage.
- **Chibaku Tensei:** rises slowly (12 seconds) and much higher, packs the rock into a real round ball, hangs a moment
  once it has gathered everything, then falls and smashes into the ground, crushing everything caught in it.
- **Earth Wall:** stone and cobblestone, 18 blocks high and 5 thick, rising row by row.
- **Kamui shuriken:** Obito's Susanoo throws two Kamui shuriken (right-click) instead of the slash. A player
  hit in the head loses 110% of their health (dead); a player hit in the body loses 15%; anything else loses 10%.
  All three numbers are in `Jutsus.toml`.
- **Ninjutsu makes every jutsu stronger:** +0.5% jutsu damage per Ninjutsu point (`ninjutsuDamagePerPoint` in
  `Stats.toml`).
- **Ban jutsu:** list jutsu ids in `bannedJutsu` in `Jutsus.toml`; nobody can cast or learn them.
- **Rasengan:** now sits where the release's emblem is, on the end of your fist.

## What's new in 1.6.0

- **Overcharging:** keep holding right-click past a full charge (1.5) and the counter keeps climbing, up to **10.0**.
  Above 1.5 the damage stays the same, but the jutsu grows: its size, blast radius and reach go up by charge / 1.5 (about
  6.7 times as big at 10). The bar refills in gold while you overcharge. An overcharged jutsu costs a bit more chakra
  (`overchargeChakraPerSize`). `maxCharge` and `overchargeSeconds` are in `Jutsus.toml`. Shinra Tensei, Chibaku
  Tensei, Poison Mist and Mind Fog charge now too.
- **Genjutsu, remade:** the target sees you burst into a flock of crows that scatter and fly away, and that's all.
  You're already behind them, and they stand frozen in the illusion for a moment (no darkness or nausea any more).
- **Medical Release** (everyone's, like Ninjutsu; the release comes with your first Medical scroll):
  - **Healing Jutsu** (C): green chakra flows from your hands into whoever you look at, healing them over two seconds,
    drawing out poison and leaving them regenerating.
  - **Poison Mist** (B): a spreading violet cloud of poison a few blocks ahead that lingers for six seconds.
  - **Cellular Activation** (A): 15 seconds of furious regeneration and resistance; poison, withering, slowness and
    fire are burned away.
- **Food from the Hidden Leaf:** Ichiraku Ramen (gives back chakra), Dango (speed), Onigiri, Yakiniku (strength),
  Lee's Curry of Life (fast healing, but spicy) and Katsudon (absorption). The shop sells these instead of vanilla
  food (the shop's list in `General.toml` is now called `stock`, so the new defaults apply).
- **Rasenshuriken:** much longer blades, and it screeches the whole time it's held or flying. When it hits, its core
  swells into a huge sphere of wind blades (7 blocks) that keeps cutting everything inside before throwing them out.
- **Rasengan in shadow clones' hands:** clones hold the real Rasengan or Rasenshuriken in their palm.
- **Water Shark Bullet** explodes when it hits: a burst of water that hurts and throws back everything around.
- **Water Prison** now lasts exactly as long as you hold right-click. You can shuffle slowly while holding it, and the
  prison stays at your hand.
- **Eight Gates:** from the Third Gate on, Ninja Jump is a teleport (up to 10-18 blocks where you look). At the Eighth
  Gate, **right-click** for Night Guy.
- **Hold Shift + Space** to keep Ninja Jumping each time you land.
- **Shadow Possession** lasts 10 seconds (`shadowPossessionDuration`).
- **Kekkei genkai scrolls are gone:** Wood, Ice, Magnet, Bone, Sealing and Rinnegan jutsu come with the kekkei genkai.
- **No [Kage] in chat** (turn it back on with `showKageTagInChat`).

## What's new in 1.5.0

- **Your sounds:**
  - Shinra Tensei, Bansho Ten'in, Chibaku Tensei, Chidori, Rasengan, Rasenshuriken, Body Flicker and Majestic
    Destroyer Flame have their voice lines.
  - Hiding in Ash, Water Clone, Mind Body Transfer, Kamui (and its snap) and the Mangekyou genjutsu do too.
  - Shadow Clone and Multi Shadow Clone share a line, and all three Wood Release jutsu play "Mokuton".
  - Every Sharingan activation (any stage, and each step up with V) makes the Sharingan sound.
  - The eyes turning off after a Mangekyou plays its own sound.
  - Shadow clones (including the Rasengan helpers) poof when they vanish.
- **The Rinnegan:**
  - A new kekkei genkai (Hagoromo and Otsutsuki have it; anyone else needs Rinnegan DNA, a 5% chance like the others).
  - It shows in the eyes while you use its jutsu.
  - **Shinra Tensei** blasts everything around you away and turns projectiles back.
  - **Bansho Ten'in** pulls the one you look at to your hand.
  - **Chibaku Tensei** throws a black sphere into the sky that rips up the ground and crushes everyone nearby into a
    growing ball of rock.
- **New jutsu:**
  - **Fire Release: Hiding in Ash** (C): a cloud of glowing ash that blinds, slows and chokes, then goes up in flames.
  - **Water Release: Water Clone** (B): two clones covered in moving water that burst into a splash when beaten.
- **Rasengan in your hand:** the ball is about the size of a head and sits in your palm (palm up when you hold it
  out) in first and third person, instead of floating past your fist.

## What's new in 1.4.0

**Every jutsu revamped** (all but Great Fireball, Water Bullet, Rising Spikes and the no-release jutsu), with models
drawn the way they look in the show. Everyone nearby sees them:
- **Fire:** Phoenix Flower's fireballs stream flaming tails. Great Fire Annihilation is a rolling sea of flame, like a
  smaller Majestic Destroyer Flame.
- **Wind:**
  - Gale Palm: gusts spiralling out of the palms with rings of pushed air.
  - Vacuum Blade: a crescent blade of air flying out, leaving after-images.
  - Great Breakthrough: dozens of gusts tearing forward behind a rolling wavefront.
- **Lightning:**
  - Chidori: a screeching ball of lightning in the hand, arcs lashing out of it and one dragging along the ground,
    and a bolt along the dash.
  - Thunder Strike: a huge forked bolt from the sky with a flash and a ring of light.
  - Lightning Armor: arcs crawling over the body.
- **Earth:** the Earth Wall heaves up out of the ground. Rock Armor covers the body in cracked stone plates.
- **Yin–Yang:**
  - Hell Viewing: dark coils and smoke round the victim's head.
  - Mind Fog: a slow ring of violet fog.
  - Mystical Palm: green chakra on both hands and round the patient.
  - Vitality Surge: the Strength of a Hundred seal, with a violet diamond on the forehead and black lines spreading
    over the body, plus a burst of golden life force.
- **Wood:**
  - Wood Binding: a root races over the ground and bark beams coil up round the target.
  - Wood Dome: grows up a ring at a time.
  - Deep Forest Emergence: twisting trunks with branches and leaves burst up, then sink back after 20 s.
- **Ice:**
  - Ice needles are glittering shards.
  - Ice Prison: a jagged cluster of ice crystals that shatters.
  - Demonic Ice Mirrors: a dome of shining mirrors with a shadowy figure flitting between them, and needles flying
    out of them.
- **Magnet:**
  - Drizzle: a black cloud raining needles.
  - Coffin: sand swirls in, closes into a shell, crushes, then bursts.
  - World Method: a sphere bursting into branching spikes.
- **Bone:**
  - Finger bones fly as real bones.
  - Dance of the Willow: bone blades jut from the forearms, elbows, shoulders and spine.
  - Seedling Fern: huge curved bone spikes erupting in waves.
- **Sealing:**
  - Barrier: a violet box covered in seal script.
  - Adamantine Chains: golden chains bursting from your back and wrapping the target.
  - Five Elements Seal: five blue flames on the fingertips and the seal burning on the target's stomach.
- Ice Prison, Ice Mirrors, Iron Sand Coffin, Seedling Fern and the Deep Forest trunks no longer place blocks. The models
  replace them, and the jutsu work the same.
- The **Ninjutsu** release has a new emblem: the grey figure making a hand sign.

## What's new in 1.3.0

**Eyes**
- **V cycles the Sharingan**: press once for the Sharingan (your highest tomoe), again for the Mangekyou, again for the
  Eternal Mangekyou, then off (stages you haven't unlocked are skipped). **X switches the Byakugan** on and off.
- With **1-3 tomoe, Genjutsu is on Jutsu 1 (R)**. With the Mangekyou: Amaterasu on R, Genjutsu stays on U.
- **Amaterasu has no cooldown** (`amaterasuCooldown`, 0), and black flames only go out with **Sneak + R**.
- **Itachi's Mangekyou** uses the pattern from your picture (on the face, in the flash and in the HUD).

**Jutsu**
- **Rasenshuriken** is formed like the Rasengan: two shadow clones pop up and shape it on your palm. It's the same
  ball with a disc of white wind blades spinning round it. Once it's ready, punch something to slam it in, or swing at
  the air (or a block) to throw it. Either way it bursts into a sphere of blades.
- **Jutsu show while you hold a release**: the Rasengan and Rasenshuriken appear on your fist (first and third person)
  and do the same damage.
- **Water Prison is held**: keep right-click down to keep the target trapped, as long as your chakra lasts (3% of max
  chakra a second, `waterPrisonDrain`; up to `waterPrisonMaxSeconds`). Let go, walk away or run dry and it bursts.
- **Water Dragon**: the body is nearly twice as long.
- **Majestic Destroyer Flame**: the wall of fire is made of tall flickering tongues of flame that lick upward, instead
  of puffs.
- **Water Shark Bullet** (new, Water, B rank, Kisame): a shark of water swims at what you look at and bites the first
  thing it reaches, eating 15 of a ninja's chakra for you. Scroll: blank scroll + prismarine shard + raw cod + lapis.
- **Mind Body Transfer** (new, Yamanaka clan, B rank): an owl hoots, and your mind leaves your body and enters the
  creature you look at (30 blocks). You see through its eyes and move, look, jump and attack with its body while yours
  stands empty. Half the damage the borrowed body takes reaches yours (`mindTransferPainShare`). Sneak to come back;
  it ends on its own after 15 s (`mindTransferSeconds`). Scroll: blank scroll + amethyst shard + feather + ender pearl.
- **Substitution** has a one-minute cooldown.
- **Death messages** name the jutsu that killed you, even if the caster has used another jutsu since it was thrown.
- **The Gate of Death kills** whoever opens it when it closes, in creative too:
  "<player> opened the 8th gate and withered away".
- **Voice lines**: every jutsu and eye technique has a sound slot. Drop `<jutsu id>.ogg` into
  `assets/shinobiarts/sounds/voice/` and it plays every time that jutsu goes off (see "Jutsu voice lines" below).

**Progression**
- **`/shop`**: buy kunai, shuriken, chakra paper, scrolls, headbands, explosive tags, TNT, food, chakra pills and
  **jutsu points** with Ryo. Everything on sale and its price is in `General.toml` → `[shop]`.
- **Leveling gets harder every level**: level N needs `xpBase + (N-1) × xpPerLevel + (N-1)² × xpGrowth` XP
  (with the defaults: about 600 XP at level 10, 4,400 at 50, 12,400 at 100, 82,000 at 300).
- **No level cap from Anbu up** (`noLevelCapFromAnbu`).
- **DNA isn't guaranteed**: a nature's DNA works 40% of the time, a kekkei genkai's 5%. If your body rejects it, the vial
  is used up and you get Slowness and Nausea for 5 minutes (`[dnaUse]` in `Spawn weights and chances.toml`).
- `clanJutsuLockedToClan` (General.toml): turn off to let anyone learn clan jutsu from scrolls.

**Interface**
- **Kekkei genkai** (Wood, Ice, Magnet, Bone, Sealing, Sharingan, Byakugan) are listed under Kekkei Genkai in the stats
  menu, not under Nature Release.
- **Team panel**: your teammates' level and health, top left of the screen and on the team page.
- **Hanging from a ceiling** shows upside down for everyone.
- **[Kage] / [Advisor] are no longer added in the player list** (so LuckPerms prefixes aren't doubled). They still
  show in chat; `showTitlesInTabList` turns the player-list tag back on.
- The config files are in the server's own `config/Naruto Generations/` folder and are sent to players who join.

## What's new in 1.2.0

- **Water Prison**: a swirling sphere of water closes around the target and drags it to your outstretched hand. Inside
  it can't move or act, its air runs out and it takes damage every second. You can turn but not walk away, or the
  prison bursts. It lasts `waterPrisonSeconds` (6 s) in `Jutsus.toml`. Very large creatures are caught where they stand.
- **Water Dragon**: water surges up out of the ground in front of you into a great translucent dragon (horned head,
  open jaws, glowing eyes, a long body that follows its path), which rises, then curves over and charges at what you
  aimed at.
- **Majestic Destroyer Flame** (Fire, S rank, new): charge it (the hand sign), and a jet of fire from your mouth bursts
  into a towering wall of flame that rolls 32 blocks forward, spreading up to 30 wide and 8 high. It burns everything
  it passes and leaves a sea of fire behind it. A tap makes a smaller wave. Scroll: blank scroll + 2 blaze rods + fire
  charge + diamond.
- **Releases are held out of sight**: the emblem of the release you hold (kekkei genkai releases too) sits on the
  underside of your hand instead of being carried like an item.
- **Config split into files**, kept together in `config/Naruto Generations/` (the server's own config folder; players
  who join are sent the server's files): `Jutsus.toml`,
  `Weapons.toml`, `Food.toml`, `Stats.toml`, `Spawn weights and chances.toml` and `General.toml`. **Every jutsu has its
  own section** in `Jutsus.toml` (`[jutsu.fireball]`...) with its chakra cost, damage multiplier, cooldown and charge.
  The old `shinobiarts-server.toml` isn't read any more: copy any values you changed into the new files.
- **Jutsu cost more chakra**: by rank, D 18%, C 22%, B 27%, A 33%, S 40% of max chakra (was 15% for all).
- **Chakra Control**: climb a wall just by walking into it while looking at it, **walk upside down on ceilings**
  (jump or climb into one, sneak to drop off; others see you hanging upside down), and **Ninja Jump from the water**.
- **Stats menu (J)**: hold a **+** to keep adding points; new **Quests** tab (your own village's quest board) and
  **Credits** tab (edit the lines in `General.toml` → `[credits]`).
- **Eight Gates**: an aura in each gate's colour around the body, flushed skin and veins from the Gate of Life on,
  much more speed, strength and damage resistance, and the **Gate of Death kills you** when it closes
  ("<player> opened the 8th gate and withered away"; `gateOfDeathKills` in the config).
- The eyes sit closer together on the face.
- **Kekkei genkai for everyone**: having one (from your clan or awakened) gives its **whole skillset** (the release
  and all its jutsu; the Byakugan brings Palm Rotation). **DNA** of every kekkei genkai (Wood, Ice, Magnet, Bone,
  Sealing, Sharingan, Byakugan) drops from the mobs you list in `Spawn weights and chances.toml` and from defeated
  players.
- **DNA for the releases too**: Fire, Water, Wind, Lightning, Earth and Yin Yang DNA unlock that chakra nature (like a
  nature scroll). Every DNA is a corked vial with the DNA symbol, its liquid in the colour of what it holds (Fire red,
  Water blue, Wind green, Lightning yellow, Earth brown, Yin Yang purple, Wood dark green, Ice light blue, Magnet
  grey, Bone ivory, Sealing pink, Sharingan crimson, Byakugan lavender).
- **Susanoo**: builds itself up over 2.5 s (bones, then body, then armor); health 1,000 / 1,800 / 4,000 / 7,000 /
  11,000; you ride in the **chest** of the Humanoid and Armored stages; the Armored stage's shield sits in front of
  its hand.
- **Shadow Possession**: a black shadow streaks along the ground to the target, which then copies every step, jump,
  turn and swing you make. New **Multi Shadow Clone Jutsu** (A rank, 10 clones; crafted from a Shadow Clone scroll,
  2 lapis and a diamond).
- **Kusanagi**: each Chidori Flow stun costs 10% of your chakra and then recharges for 15 s.
- **Death messages name the jutsu** ("Steve was killed by Alex's Chidori").
- **Clans**: claim **any** clan you rolled (`/clanroll claim <clan>`, or click it in chat), and every clan's bonuses
  are now potion effects (see the table below).
- **Kage** can post one quest every 60 minutes (`kageQuestCooldownMinutes`).
- **HUD**: the "hold a release" hint stays on the scroll, Ryo is shortened (1.2k, 15k, 250k, 1.5M), and an XP bar
  sits before your level.
- **Creative tabs**: releases, then nature scrolls, then jutsu scrolls grouped by release; the swords of the Seven
  Ninja Swordsmen have their own tab. The Gunbai and Kabutowari are bigger.

## Controls (rebind in Options → Controls → Naruto Generations)

| Key | Action |
|---|---|
| **Right-click** | Cast the selected jutsu of the release you're holding |
| **G / H** | Move the jutsu arrow right / left |
| **J** | Stats menu |
| **Z** (hold) | Charge chakra (standing still also gathers Senjutsu) |
| **B** | Toggle Sage Mode |
| **V** | Sharingan: press once for your highest tomoe, again for the Mangekyou, again for the Eternal Mangekyou, then off |
| **X** | Byakugan on/off |
| **R / Y / U** | Jutsu 1 / Jutsu 2 / Jutsu 3: your eyes' techniques (1-3 tomoe: Genjutsu on R; Mangekyou: Amaterasu on R, Sneak + R puts the flames out; Kamui is held on Y) |
| **K** | Toggle Substitution: while it's on, attacks hit a log instead of you (needs the Substitution Jutsu) |
| **N** | Toggle Chakra Control: walk up walls (walk into them looking at them), hang from ceilings, walk on water |
| **I** | Eight Inner Gates: open the next gate (Shift + I closes them all) |
| **O** | Susanoo (Mangekyou on): summon it, press again to grow it a stage (Shift + O releases it) |
| **M** | Jinchuriki: let the tailed beast's chakra out (its rage form, or once tamed its chakra cloak; again to let the cloak go) |
| **Right-click** (chakra cloak, empty hand) | Tailed Beast Bomb |
| **Left-click** (Rasenshuriken ready) | Throw it (punching something slams it in instead) |
| **Shift + Space** | Ninja Jump from the ground, or from the water with Chakra Control on (15 chakra, no cooldown); hold both to keep jumping. From the Third Gate on it teleports you instead |

Your health bar sits above the hotbar where the hearts were. The panel to the left of the hotbar shows
Ryo, level, the chakra figure with the soft chakra and Senjutsu bars, and the jutsu slots of the release you're holding.
Every time you join a world or server, a clickable Discord invite appears in chat.

## How it works

### Clans
There are **30 clans**. New players start without one and roll it with **`/clanroll`**:
- Each `/clanroll` rolls a new clan (replacing the last one). Every player gets **2 rolls** (`clanRolls` in the config).
- **`/clanroll claim`** locks the current clan in for good. After that, `/clanroll` says
  *"Sorry, you already claimed your clan."*
- With no rolls left, `/clanroll` says *"You have used all of your rerolls!"* and the last rolled clan stays.
- Rolling away from Uchiha takes back the Sharingan you got with it; clans with a fixed nature (e.g. Uchiha = Fire)
  set your affinity unless you've already revealed it with Chakra Paper.
- Players from older versions keep the clan they had, already claimed. `/shinobi clanroll <player> reset` gives
  someone their rolls back.

The clan's bonuses are passive and always on. Hover over your clan in the stats menu (J), or type `/clan`, to see
them. `/clan list` shows every clan and its chance, and `/clan info <clan>` shows any clan's bonuses. Rare and
Mythic rolls are announced to the whole server.

| Rarity | Chance (each) | Clans |
|---|---|---|
| Mythic | 1 in 100,000 per roll | Ōtsutsuki |
| Rare | 1 in 138 per roll | Uchiha, Senju, Uzumaki |
| Uncommon | 1 in 46 per roll | Hyūga, Kurama, Kaguya, Yuki, Kazekage, Chinoike, Hagoromo |
| Common | 1 in 23 per roll | Nara, Akimichi, Yamanaka, Aburame, Inuzuka, Sarutobi, Hatake, Shimura, Fūma, Hōzuki, Hoshigaki, Karatachi, Shirogane, Yotsuki, Kamizuru, Iburi, Tsuchigumo, Funato, Taketori |

| Clan | Bonuses |
|---|---|
| **Ōtsutsuki** | Byakugan, Strength III, Speed II, Resistance II, Regeneration II, Health Boost III, Slow Falling I, Chakra Regeneration 1.5x |
| **Uchiha** | Fire affinity, Sharingan at birth, Speed II, Fire Resistance I, Night Vision I (while the Sharingan is on) |
| **Senju** | Earth affinity, Health Boost II, Regeneration I, Resistance I, Chakra Regeneration 1.75x (Wood Release blood) |
| **Uzumaki** | Health Boost III, Regeneration II, Resistance I, Fire Resistance I, Chakra Regeneration 2x, double shadow clones |
| Hyūga | Byakugan, Speed I, Jump Boost II, Resistance I, Night Vision I (while the Byakugan is on), Palm Rotation |
| Kurama | Night Vision I, Resistance I, Chakra Regeneration 1.25x |
| Kaguya | Strength II, Resistance II, Health Boost II |
| Yuki | Water affinity, Fire Resistance I, Resistance I, Water Breathing I |
| Kazekage | Earth affinity, Resistance II, Slow Falling I, Health Boost II |
| Chinoike | Night Vision I, Strength I, Resistance I |
| Hagoromo | Health Boost II, Regeneration II, Resistance II, Chakra Regeneration 1.5x |
| Nara | Night Vision I, Speed I, Resistance I, Shadow Possession |
| Akimichi | Strength II, Resistance II, Health Boost II, Slowness I |
| Yamanaka | Speed I, Night Vision I, Resistance I |
| Aburame | Resistance I, Night Vision I, Poison Immunity, Speed I |
| Inuzuka | Speed II, Jump Boost II, Strength I, Night Vision I |
| Sarutobi | Fire affinity, Strength I, Fire Resistance I, Resistance I |
| Hatake | Lightning affinity, Speed III, Strength I, Resistance I, Permanent Saturation (never hungry) |
| Shimura | Wind affinity, Speed I, Resistance I, Fire Resistance I |
| Fūma | Speed II, Jump Boost II, Strength I |
| Hōzuki | Water affinity, Water Breathing I, Dolphin's Grace II, Speed I |
| Hoshigaki | Water affinity, Water Breathing I, Dolphin's Grace III, Strength II, Resistance I |
| Karatachi | Water affinity, Water Breathing I, Speed I, Resistance I |
| Shirogane | Speed I, Night Vision I, Resistance I |
| Yotsuki | Lightning affinity, Speed II, Strength II, Jump Boost II, Resistance I |
| Kamizuru | Speed I, Night Vision I, Poison Immunity |
| Iburi | Speed II, Slow Falling I, Fire Resistance I |
| Tsuchigumo | Strength II, Resistance II, Health Boost II |
| Funato | Water affinity, Water Breathing I, Dolphin's Grace II, Speed I |
| Taketori | Strength II, Resistance I, Speed I |

The effects are kept topped up without particles. Health Boost is given as permanent max health (4 per level), so it
never resets your hearts. The chances are in `Spawn weights and chances.toml` (a weight per tier, and `mythicChance` for
Ōtsutsuki); `/shinobi clan <player> <clan>` sets one directly.

### Releases and jutsu
- There are 7 releases: Fire Release, Water Release, Wind Release, Lightning Release, Earth Release, Yin Yang Release,
  and Ninjutsu Release, plus 5 **clan releases** that only one clan can use (see *Clan releases* below).
  **Hold one** (either hand) to equip it: its octagon emblem sits small and flat on the underside of your hand (only
  seen from below; in first person you just see your bare hand), and the HUD shows its jutsu slots.
- New players get the **Ninjutsu Release**, empty at first.
- **Chakra Paper** reveals your nature affinity and gives you that release. **Training Scrolls**
  unlock more natures, including Yin Yang.
- **Jutsu scrolls** teach a jutsu permanently and add it to its release's slots. Shadow Clone,
  Rasengan, Body Flicker and clan jutsu go in Ninjutsu. Substitution has its own key instead (see below).
- Every jutsu has a **rank from the show**, D (weakest) to S (strongest). The rank is on the scroll's tooltip
  and colors its name, and the creative tab lists scrolls from D to S. D, C and B rank can be learned at any level;
  only A and S rank need a minimum level (configurable in `jutsuRanks`):

| Rank | Level | Jutsu |
|---|---|---|
| D | any | Substitution, Body Flicker, Hell Viewing, Water Bullet |
| C | any | Great Fireball, Phoenix Flower, Water Prison, Gale Palm, Great Breakthrough, Mind Fog, Shadow Possession |
| B | any | Great Fire Annihilation, Water Dragon, Vacuum Blade, Earth Wall, Rock Armor, Rising Spikes, Shadow Clone |
| A | 90 (Chunin) | Lightning Armor, Chidori, Thunder Strike, Mystical Palm, Rasengan, Eight Trigrams Palm Rotation |
| S | 175 (Jonin) | Majestic Destroyer Flame, Vitality Surge, Rasenshuriken |

Clan release jutsu have ranks too (C, B, and A or S; see *Clan releases*).

- **Hold right-click to charge** a jutsu that deals damage, and let go to cast it. A counter under the crosshair shows
  the charge and the damage it will do: a quick tap casts at x0.6, a full charge at x1.5. Keep holding to
  **overcharge** up to 10.0 (no more damage, but the jutsu grows up to about 6.7 times as big; a pulsing gold **MAX** at
  the top). A full charge takes 0.5 s for D rank up to 2.5 s for S rank; chakra gathers around your hands and a chime
  plays when it's full. The counter turns red if the jutsu is still cooling down or you're short on chakra.
  Utility jutsu (Substitution, Body Flicker, armors, walls, healing, Shadow Clone...) still cast the moment you click.
  Everything is in the `charging` config section (set `enabled = false` to cast every jutsu on click).
- **Rasengan**: two shadow clones (wearing your skin) pop out of smoke on either side of you and cup their hands round
  your palm while the ball grows and spins faster; after about 1.5 s they vanish and you hold it on your fist (about
  a block across, everyone can see it) until your next punch sets it off. It can't hit anything while it's forming.
  It's drawn from OPREXT's Partical Rasengan model.
- **Rising Spikes** bursts the Earth Flow Spike Cluster out of the ground where you look: one big cluster in the middle
  and four smaller ones round it, which stand for 2 seconds and sink back. The damage and launch are the same as before.
- **Great Fireball** grows with its charge: a quick tap throws a small fireball, a full charge a huge one with a
  bigger blast (about 2 to 5.5 blocks). It and the **Water Bullet** are drawn as glowing balls, and **Lightning
  Armor** wraps you in a crackling blue shell that everyone can see.
- **Substitution** is a toggle: once you've learned it from its scroll, press **K** to switch it on (the HUD shows
  *Substitution*, grey while it's cooling down). While it's on, a hit from a creature or player misses you: you jump
  4 blocks back (away from the attacker) and 2 up, and leave 2 logs where you stood that vanish after 10 seconds.
  You take no fall damage from the jump. Each swap costs the jutsu's chakra (15% of max) and starts its 8 s cooldown;
  without enough chakra, or while it cools down, hits land normally. Press K again to switch it off.
  (`substitutionBlocksBack`, `substitutionBlocksUp`, `substitutionLogSeconds` in the `jutsuTuning` config section.)
- **Chakra Control** (press **N**; anyone can use it): walk into a tree or wall **while looking at it** (or up) to walk
  up it; sneak to cling in place. Looking away while pushing against it, you slide down slowly and take no fall
  damage; step away from the wall to drop. Jump or climb into a **ceiling** to hang from it upside down and walk around;
  sneak to drop off. You also **walk on water** (sneak to sink in and swim) and can **Ninja Jump** from the water. It
  drains 0.5 chakra a second while you're climbing, on a ceiling or standing on water and stops working below 1 chakra
  (`chakraControl` in `Jutsus.toml`).
- **Jutsu cost a share of your max chakra by rank**: D 18%, C 22%, B 27%, A 33%, S 40% (more Ninjutsu points mean
  more casts). Each jutsu's cost, damage, cooldown and charge are in its own section of `Jutsus.toml`, and
  `chakraCostMultiplier`, `damageMultiplier` and `cooldownMultiplier` scale them all.
- Jutsu scrolls are colored by the release they go into, training scrolls by their nature: Fire red, Water blue,
  Wind teal, Lightning yellow, Earth brown, Yin Yang black, Ninjutsu (and the Nara and Hyuga clan jutsu) purple,
  Wood green, Ice pale blue, Magnet iron grey, Bone ivory, Sealing rose. Their inventory pictures are rendered from the
  3D scrolls.

### Clan releases
Five clans have a release of their own (kekkei genkai), shown as an octagon emblem with its kanji like the others:

| Release | Clan | Kanji |
|---|---|---|
| Wood Release | Senju | 木 |
| Ice Release | Yuki | 氷 |
| Magnet Release | Kazekage | 磁 |
| Bone Release (Dead Bone Pulse) | Kaguya | 骨 |
| Sealing Release | Uzumaki | 封 |

- **When your clan is yours for good** (`/clanroll claim`) you get the release **and all three of its jutsu** (a chat
  message announces it). An admin moving you to another of these clans gives you that clan's release instead.
- **Anyone can gain a kekkei genkai**: right-click its **DNA** (dropped by the mobs listed in `Spawn weights and
  chances.toml` and by defeated players) or read one of its jutsu scrolls. You get the release and all of its jutsu
  straight away. Sharingan and Byakugan DNA give the eyes (the Byakugan also brings Palm Rotation).
- Nature DNA (Fire, Water, Wind, Lightning, Earth, Yin Yang) drops the same way and unlocks that release once your
  affinity is revealed. Mob drops pick any of the 13 DNA at random; a defeated player drops one of their own natures or
  kekkei genkai.
- Holding another clan's release does nothing (its tooltip says whose it is), and the Sharingan can't copy these jutsu.
- Blocks they make (wood, ice, iron sand, bone spikes) go only into empty space (plants too with jutsu griefing on),
  never into a creature, break by themselves and drop nothing; you can break out of them.

| Release | Jutsu | Rank | What it does | Cooldown |
|---|---|---|---|---|
| Wood | **Wood Binding** (given) | C | Roots race to the creature you look at (24 blocks) and coil round it: 6 damage and held fast for 4 s (no moving, attacking or jutsu) | 10 s |
| Wood | **Wood Dome** | B | A dome of wood (radius 3) grows up around you and keeps out attacks and projectiles for 10 s | 30 s |
| Wood | **Deep Forest Emergence** | S | A forest bursts out of the ground where you look (9 x 9): the rising trees deal 10 damage and throw everything up, then for 20 s the roots deal 1.5 damage a second, slow and drag in whoever stays | 60 s |
| Ice | **Ice Needles** (given) | C | A fan of 8 ice needles, 2 damage each (every needle counts), each slows and chills | 2 s |
| Ice | **Ice Prison** | B | 5 damage and the target freezes solid inside a crystal of ice for 3 s, then it shatters | 12 s |
| Ice | **Demonic Ice Mirrors** | A | A dome of 20 ice mirrors around the target; for 6 s needles fly from the mirrors (15 hits of 1.5) while it stays inside | 30 s |
| Magnet | **Iron Sand Drizzle** (given) | C | Iron sand rains on where you look (5 blocks wide): 8 volleys of 1.5 damage | 3 s |
| Magnet | **Iron Sand Coffin** | B | Iron sand swallows the target, holds it, and crushes it shut 1.5 s later for 16 damage | 12 s |
| Magnet | **Iron Sand World Method** | A | A mass of iron sand forms in front of you and bursts into spikes in every direction: 16 damage to everything within 8 blocks of it, thrown back | 20 s |
| Bone | **Finger Bone Bullets** (given) | C | Five bone bullets in a row (3.5 damage each) wherever you're aiming | 2 s |
| Bone | **Dance of the Willow** | B | Bones jut out like blades and armor: Strength II and Resistance I for 20 s | 30 s |
| Bone | **Dance of the Seedling Fern** | A | Huge bone spikes erupt around you in 4 waves out to 9 blocks: 14 damage and thrown up (once each); the spikes stand 8 s, then sink | 30 s |
| Sealing | **Barrier** (given) | C | A sealing barrier around you for 8 s: arrows, thrown weapons and projectile jutsu are stopped at its edge, creatures that come at you are pushed back out | 20 s |
| Sealing | **Adamantine Sealing Chains** | B | Chakra chains bind the target for 4 s (3 damage); a ninja loses 30% of their chakra, a creature is weakened | 15 s |
| Sealing | **Five Elements Seal** | A | Up close (5 blocks): seals the target's chakra for 10 s, no jutsu, eye techniques or Eight Gates; a ninja's eyes switch off and open gates close | 45 s |

Damage numbers are before the damage multiplier, upgrades and charging. Deep Forest, the Ice Needles and Mirrors, all
three Magnet jutsu, the Finger Bone Bullets and the Seedling Fern charge and can be upgraded with Jutsu Points.

### Sharingan
- **Anyone can own the Sharingan.** Uchiha are born with a 1-tomoe Sharingan; anyone else gets one by taking it.
- **Evolution, one stage at a time:** 1 tomoe → 2 tomoe at level 30 → 3 tomoe at level 60 → **Mangekyou** once
  you're level 100 with 3 tomoe *and* survive a near-death experience (health at or below 5% of max).
- Press **V** to switch it on (it drains chakra). Your face shows the eyes of your stage to everyone, and the
  eyes flash across your screen when you switch them on or they evolve.
- Stronger stages dodge more hits (12% / 18% / 25% / 32%, raised by Genjutsu, max 50%) and copy jutsu from
  farther away.
- **Mangekyou patterns:** an awakened Mangekyou takes **Itachi's, Sasuke's or Obito's** pattern at random. It shows on
  your face, in the screen flash and in the HUD's eye slot, and it decides your eye techniques: Itachi has Amaterasu
  and Tsukuyomi, Sasuke has Amaterasu and Blaze Release, Obito has Kamui. Implanting a
  stolen Mangekyou eye into your own Mangekyou awakens the **Eternal Mangekyou**.
- **Eye techniques** (Jutsu 1/2/3 keys, R/Y/U by default; your Sharingan must be on). They show next to your armor
  above the HUD scroll, with their key and cooldown. **Every eye's tooltip lists its techniques and the keys you have
  bound for them** (the eyes in your dojutsu slot, stolen Sharingan Eyes, and the Sharingan item):

| Key | Eyes | Technique |
|---|---|---|
| Jutsu 1 | Itachi, Sasuke, Eternal | **Amaterasu**: black flames on the spot you look at (and on the creature there). They burn anything that walks in, never spread or burn blocks, can't be put out with water, and die out after 5 minutes. **Sneak + Jutsu 1** puts out every black flame within 10 blocks. Strains your eyes (blindness + 1 heart), except the Eternal Mangekyou. 25% chakra, no cooldown |
| Jutsu 2 (hold) | Obito | **Kamui**: while you hold the key you're intangible: you **fly through blocks**, and attacks, arrows and jutsu pass through you (you can't hurt anyone either). Let go to come back; if you're inside a wall, you come out at the nearest open spot. Lasts up to 15 s. 20% chakra + 3 per second, 10 s cooldown after it ends |
| Sneak + Jutsu 2 | Obito | **Kamui snap**: tears at the creature you look at for **50% of its max health**, ignoring armor (bosses at most 20). 30% chakra, 30 s cooldown |
| Jutsu 2 | Itachi | **Tsukuyomi**: the creature or player you look at (20 blocks) is frozen for 4 seconds: they can't move, attack or use jutsu, players lose 40% of their chakra and their screen turns red and black. When it ends they take **25% of their max health** at once, ignoring armor (bosses at most 20), then nausea and slowness. A victim with their Sharingan on is held half as long. Strains your eyes. 30% chakra, 40 s cooldown |
| Jutsu 2 | Sasuke, Eternal | **Blaze Release**: spikes of black flame burst out of the ground in a line 15 blocks toward where you look; everything they hit takes 9 damage and catches Amaterasu. Strains your eyes (not the Eternal). 25% chakra, 20 s cooldown |
| Sneak + Jutsu 2 | Sasuke, Eternal | **Flame Wall**: a 7-block wall of black flames 3 blocks ahead for 15 seconds. Anything walking into it burns with Amaterasu and is thrown back; arrows and jutsu thrown through it burn up. 25% chakra, 30 s cooldown |
| Jutsu 1 (1-3 tomoe), Jutsu 3 (Mangekyou) | every Sharingan | **Genjutsu**: the one you look at sees you burst into crows and fly away, while you appear behind them; they're frozen in the illusion for a moment (longer with each stage, the Mangekyou and Genjutsu). 10% chakra, 20 s cooldown |

  All numbers are in the `eyeTechniques` config section. Amaterasu used to be a jutsu scroll: players who learned it
  get their Jutsu Points back, and old Amaterasu scrolls turn into Blank Scrolls.
- **Byakugan techniques** (Hyūga and Ōtsutsuki, with the Byakugan on; same keys):

| Key | Technique |
|---|---|
| Jutsu 1 | **Eight Trigrams 64 Palms**: dash to the creature or player within 6 blocks and strike 8 times (24 damage in all). Their **chakra points are sealed** for 8 seconds: no jutsu, eye techniques or Susanoo. Players also lose half their chakra; creatures are slowed and weakened. 20% chakra, 25 s cooldown |
| Jutsu 2 | **Air Palm**: a blast of air down your line of sight (20 blocks): 10 damage and a big knockback. 8% chakra, 5 s cooldown |
| Jutsu 3 | **All-Seeing Eye**: for 20 seconds everything living within 60 blocks glows through walls (invisible players too), and the top of your screen warns you when a player or monster is right behind you. 10% chakra, 40 s cooldown |

  The Byakugan now shows on your face (with the veins around the eyes) and flashes across your screen when you
  switch it on, like the Sharingan.
- **Taking eyes:** defeating a Sharingan user in PvP (a kill that gives PvP rewards) gives you a **Sharingan Eye**
  (a Mangekyou eye keeps its pattern). Right-click it to implant it: you get its stage, limited by your level
  (a Mangekyou eye needs level 100). Players who weren't born Uchiha lose their Sharingan when it's taken; Uchiha
  keep their bloodline eyes.
- **Dojutsu slot:** your inventory has an extra slot just above the off-hand, marked with a grey Sharingan (the way
  empty armor slots show a grey helmet). **Switching your eyes on (V) puts them in the slot**: your Sharingan at its
  stage and Mangekyou pattern, or the Byakugan. They're locked there, and **switching them off takes them out again**
  (so does running out of chakra or dying).
  While your eyes are off, the slot can hold the **Sharingan** item (2 Eyes of Ender and a block of redstone, in a
  row; right-click it to put it on): cosmetic eyes, 3 tomoe on your face, and your helmet slot stays free for real
  armor. Switching your own eyes on moves it back into your inventory. It drops on death like armor. Sharingans worn
  as helmets before this update move into the slot on their own.

### Susanoo
With the **Mangekyou Sharingan switched on**, press **O** to summon a Susanoo around you. Press O again to grow it
into the next stage, as far as your level allows; **Shift + O** releases it.

| Stage | Look | Level | Health | Takes for you | Left-click combo (empty hand) | Right-click special (empty hand) |
|---|---|---|---|---|---|---|
| 1 Ribcage | spine and ribs over chakra flames, 4 blocks | 100 | 300 | 70% | none (shoves attackers back) | none |
| 2 Skeletal | skull and clawed arms, 7 blocks | 125 | 600 | 85% | 10 / 10 / 15, reach 5 | Ground slam: 18 within 4 blocks, launches up (6 s) |
| 3 Humanoid | chakra muscle, fierce face, sword, 10 blocks | 150 | 1,200 | 100% | 16 / 16 / 24, reach 7 | 3 homing magatama, 12 each (8 s) |
| 4 Armored | samurai armour, horned helmet, shield, 14 blocks | 200 | 2,500 | 100% | 22 / 22 / 33, reach 8 | Chakra slash wave: 35, 30 blocks, goes through everything (10 s) |
| 5 Perfect | a winged giant with a greatsword, 24 blocks | 250 + Eternal Mangekyou | 5,000 | 100% | 40 / 40 / 60, 16 blocks wide | Giant slash wave: 70, 50 blocks, 16 wide (15 s) |

- **It takes the hits meant for you** on its own health bar (top of the screen). You take no knockback and no fall
  damage while it stands. Health grows with your max chakra (half as fast). Others can also hit it directly.
- **Shift blocks**: hits from the front do 60% less; the Armored stage's shield blocks 90%; the Perfect stage's wings
  wrap round you and block 75% from every side. You can't swing while blocking.
- It **heals** 2% a second once it hasn't been hit for 5 seconds (that costs a little chakra). At 0 it **shatters**
  and you can't summon it again for 30 seconds.
- **Chakra**: summoning or growing costs 10/15/20/25/35% of your max chakra, and it uses 1/1.5/2/2.5/3.5% every
  second. When you run out it fades. Specials cost 5-10%.
- **Counters**: Amaterasu sets it alight (4% of its health a second instead of burning you); the Kamui snap and
  Tsukuyomi go straight through it. Sealed chakra (Five Elements Seal, 64 Palms) or your eyes switching off end it,
  and the Eight Gates can't be opened inside one (or the other way round).
- The combo hits everything in an arc in front; the third swing hits harder and throws them back. Damage gets your
  Kenjutsu bonus and the damage multiplier.
- **The Perfect Susanoo carries you in its forehead crystal**, 20 blocks up. Fly as usual (space up, Shift down) and
  it goes with you: it walks when it's on the ground (its feet never sink into it) and beats its wings in the air.
  It turns where you look. In first person its head isn't drawn and the screen edges take the crystal's tint;
  others see you through a glassy head. Releasing it sets you back on the ground.
- **Colours**: `/susanoo color <part> <colour>` with a preset (purple, blue, light_blue, red, green, yellow, orange,
  white, cyan, pink) or any `#RRGGBB`. Parts: `body`, `armor`, `weapon`, `eyes`, `chakra` (the rim light and glow),
  `aura`, or `all` with a preset. `/susanoo colors` shows yours, `/susanoo color reset` goes back to purple.
- Your own arrows, jutsu and crosshair go straight through your Susanoo.
- Everything is in the `susanoo` config section (levels, health, how much it takes, chakra, combo and special damage,
  cooldowns, block strength, Amaterasu burn). Specials can break blocks if you turn `specialsBreakBlocks` on.
- The models are smooth meshes made by `tools/make_susanoo.py` (from `tools/susanoo/`): see-through bodies tinted in
  your colours, with a rim of chakra light and a soft glow around the edges. Its swings, special and blocking poses
  are keyframes in `tools/susanoo/anims.py`.

### Eight Inner Gates
The taijutsu path for ninja without special eyes. Press **I** to open the next gate, one at a time; **Shift + I**
closes them all. Each gate needs **10 more Taijutsu points** (the eighth needs 80).
- Every open gate adds **+8% speed, +10% attack speed, +2 bare-hand damage** and higher jumps.
- **Gate 2 (Healing)** heals 4 hearts when it opens.
- **From gate 3 on, the gates cost health every second**: 0.5, 1, 1.5, 2 and 3 for gates 3-7. They never kill you:
  at half a heart they close themselves. Closing gate 5 or higher leaves your muscles sore (weakness and slowness
  for a few seconds).
- Your aura steams **blue**, **green from gate 6**, and **red at gate 8**. The HUD shows which gate is open.
- **Gate 8, the Gate of Death:** double bare-hand damage and more speed for 20 seconds. **Right-click** for
  **Night Guy**: a dash of up to 16 blocks that hits everything in its path for 100 damage. When the gate closes
  you're left at **one heart**, badly weakened for a minute, and **the gates stay locked for 10 minutes**.
- Everything is in the `eightGates` config section.

### Forehead protectors
Craft one from an **iron ingot and 2 wool** (any colour) and wear it in the helmet slot (1 armor). The metal plate
(from Calfan's Naruto Headbands model) sits on the cloth and shows **the village of whoever wears it**: Hidden Leaf,
Sand, Mist and Cloud have their own symbols, and so do villages with the ids `rain` and `sound` if you add them.
Without a village it's the **scratched Leaf plate**, like a rogue ninja's. Stone, other villages and a protector
nobody has worn yet show **忍** (shinobi). Dye the band like leather armor (navy blue by default). To give a village
its own plate, add `assets/shinobiarts/textures/entity/headband/plate_<village id>.png` (512 x 173, transparent
outside the plate) in a resource pack.

### Advancements
Open the advancements screen (**L**) for two new tabs:
- **Naruto Generations:** one advancement per release (Fire Release, Water Release...) with every jutsu of that
  release under it (the clan releases stay hidden unless they're yours), plus the Sharingan's stages (Sharingan, Two Tomoe, Three Tomoe, Mangekyou, each Mangekyou
  pattern, Eternal Mangekyou) and the Byakugan. You get one each time you learn a jutsu, unlock a release or awaken
  an eye; S-rank jutsu and the Mangekyou are challenges.
- **Shinobi Clans:** one hidden advancement per clan, given once your clan is yours for good (`/clanroll claim`, or
  no rolls left). It's announced in chat, so everyone sees which clan you belong to.

Like vanilla advancements they're announced in chat (the `announceAdvancements` game rule turns that off). Players
who already had jutsu, releases or eyes get those advancements, all at once, the first time they join with this
version.

### Shadow clones
- Clones copy your **hand jutsu**: cast Rasengan, Chidori or Rasenshuriken and each clone gets one too. They
  use Rasengan up close or **throw it** from range, dash in with Chidori, and throw Rasenshuriken.
- While your Sharingan is on, your clones have it too (same stage, they can dodge hits); switch it off and
  theirs goes away.

### Combat tag and vault
- Hitting or being hit by another player (directly, with jutsu or through clones) puts **both** of you in
  combat for 60 seconds: `In Combat (60) - Username` shows at the top of the screen.
- In combat **every command is blocked** (from any mod), and **logging out kills you**; your opponent gets the kill.
- `/vault` opens your personal 54-slot vault. Vault items stay through death.

### Teams
- `/team create <name>`, `/team invite <player>` (they click [Accept]), `/team leave`, `/team kick <name>`,
  `/team disband`, `/team info`. Up to 4 players per team. Your team and who's online show in the stats menu (J).

### Levels and stats
- Gain XP by killing hostile mobs (5 XP each, 100 XP for the first level), from PvP, and from
  **Ninja EXP Bottles** (100 XP each). Update 2 adds quests and bandits.
- **XP Boost Tokens** (1.5x or 2.5x, for 30 minutes or 1 hour): right-click to multiply the XP you earn from
  mobs and PvP. The timer (shown on the HUD) only runs while you're online. A stronger token replaces a
  weaker boost; the same one adds time.
- Each level gives **4 stat points** and **250 Ryo**.
- **Ranks cap your level:** Genin 75, Chunin 150, Jonin 250, Anbu 400, Sannin 500. At the cap, XP is saved
  until you're promoted (by a Kage in Update 2, or `/shinobi rank`).
- Spend points in the stats menu (J); shift-click adds 5. Resetting refunds every point for Ryo
  (500 + 100 per level), with a confirmation screen.
- New players start with a **Frog Wallet** and **3 kunai** (plus the empty Ninjutsu release).

### Jutsu Points and upgrades
- Each level-up has a **35% chance** to give **2-6 Jutsu Points**.
- In the stats menu (J), the **Jutsu** tab lists your learned jutsu that deal damage. **20 points** upgrade one of them
  by **+15% damage**, up to **5 times** (+75%). The bonus applies wherever that jutsu deals damage: Rasengan's punch,
  projectiles, and the copies your shadow clones throw.
- Utility jutsu (Substitution, armors, walls, healing, Shadow Clone itself) can't be upgraded.
- All of the numbers are in the `jutsuUpgrades` config section; `/shinobi jutsupoints` gives points for testing.

| Stat | Effect per point (default) |
|---|---|
| Taijutsu | +0.5 punch damage (bare hand or holding a release) |
| Kenjutsu | +0.4 sword damage |
| Genjutsu | +2% Sharingan dodge/copy range, Amaterasu, Shadow Possession and Yin illusions |
| Medical | +1 max health (half a heart), stronger Yang healing |
| Speed | +1% movement speed (max 50 points, the only capped stat) |
| Ninjutsu | +5 max chakra, slightly faster chakra regen |
| Senjutsu | +10 max natural energy for Sage Mode |

### PvP
- Landing hits on other players gives a little XP (max 30 per minute). Defeating a player gives XP and Ryo,
  more for higher-level opponents.
- **Level-gap rule (both ways):** fights between players whose levels are too far apart give no rewards.
  Strong players get nothing for beating new players, and new players get nothing for beating strong ones
  (so nobody can boost an alt). Anyone can still fight and kill anyone. The allowed gap is the larger of
  10 levels and half the lower player's level: level 1 and level 12+ players get nothing from each other,
  and a level 100 player can be rewarded against levels 50-150.
- No rewards for beating the same player again within 10 minutes, or for killing an AFK player.
  Shadow clone and jutsu kills count as yours. All values are in the `pvp` config section.

### Ryo and the Frog Wallet
- Coins: **Bronze = 100**, **Silver = 500**, **Gold = 1,000** Ryo.
- Right-click the **Frog Wallet**: its mouth opens to show your Ryo and the deposit/withdraw buttons.
  Click the tongue to close it.
- Your Ryo is stored on your player, not in the wallet item. Dropping, losing or copying a wallet never
  loses or duplicates money, and every transfer is checked by the server.

### Ninja weapons
All of them are swords, so Kenjutsu adds to their damage. They live in the **Ninja Tools** creative tab
with the kunai, shuriken and explosive tags. Damage is the number on the tooltip (change it in the
`weapons` config section).

| Weapon | Damage | Speed | Reach | Special |
|---|---|---|---|---|
| Samehada | 34 | 0.7 | +1 | Eats chakra: steals 10 from players you hit, and gives you 5 on every hit |
| Kubikiribocho | 32 | 0.8 | +1 | Repairs itself with every hit |
| Kabutowari (Helmet Splitter) | 26 | 0.8 | +0.5 | **Dual: axe in your hand, hammer in your empty off hand.** Breaks any defence: armor stops 40% less of its damage, and it knocks a raised shield (or a guarding Gunbai) out of use for 5 s |
| Hidan's Triple-Bladed Scythe | 24 | 0.9 | +1.5 | Heals you for 20% of the damage you deal |
| Sword of Fire | 19 | 1.2 | | Sets targets on fire |
| Gunbai | 18 | 1.0 | +1 | **Hold right-click to guard** like a shield: blocks hits from the front, and jutsu and arrows that hit it fly back at whoever threw them. Its swings knock targets back |
| Shakujo Staff | 17 | 1.1 | +1.5 | Heavy knockback |
| Kiba Blades | 16 | 1.9 | | **Dual: a blade in each hand.** Hits spark lightning onto up to 2 nearby enemies for 30% damage (3 chakra). **Right-click** calls lightning down where you look (15 chakra, 8 s cooldown) |
| Kusanagi Sword | 15 | 1.8 | | Chidori Flow: hits spend 4 chakra to paralyse the target |
| Katana | 11 | 1.6 | | |

### Sage Mode
Invest in Senjutsu, then hold **Z** while standing still to gather natural energy (green bar).
Press **B** for Sage Mode: Strength, Resistance, Jump Boost and +25% jutsu damage until the energy runs out.

### Villages and the quest board (Update 2)
Five villages by default: Hidden Leaf (`leaf`), Sand (`sand`), Mist (`mist`), Cloud (`cloud`) and Stone (`stone`).
The list is in the config (`id:Display Name`), so you can rename them or add more.

**Joining a village** is done with permissions (LuckPerms or any permission plugin that works with Forge):

| Permission node | Gives |
|---|---|
| `shinobiarts.village.<id>` | membership, e.g. `shinobiarts.village.leaf` |
| `shinobiarts.village.<id>.kage` | Kage of that village (also counts as a member) |
| `shinobiarts.village.<id>.advisor` | Village Advisor of that village (the player also needs membership) |

Example: `/lp user Steve permission set shinobiarts.village.leaf true`. Membership is re-checked whenever a player
joins or opens the board. Without a permission plugin, operators use `/shinobi village` and `/shinobi kage` (below).

**`/village`** (or `/village <id>`) opens your village's quest board:
- Tabs for **Hourly** (2 quests), **Daily** (3), **Weekly** (2), **Monthly** (1) and **Kage** quests. Random quests
  are rolled for each player when the period starts, and the tab shows when they refresh.
- **Accept** or **Decline** each quest. Only accepted quests count.
- Quest kinds: defeat Ninja Bandits, defeat hostile mobs, defeat enemy players, catch fish, and bring items
  (logs, wheat, bread, iron, diamonds). Item quests complete as soon as you carry the items.
- **Claim** pays the reward (EXP bottles plus Ryo, straight into your wallet balance) and hands the items in:
  **every handed-in item goes to the village storage**, for random quests and Kage quests alike. If the storage
  is full, the quest waits until the Kage makes room.
- The bottom of the board shows the village's **Advisors** ("Need help? Advisors: ..."), online ones in green.

**`/village <id> admin`** opens the **Kage menu** (Kage only):
- **Post a quest**: hold the item you want brought in, then set the amount, EXP bottles and Ryo (capped by the config).
  Every member sees it under the Kage tab. Items handed in for Kage quests go to the village storage.
- **Remove** posted quests (×), **promote or demote** online members (+ / −, Genin → Chunin → Jonin; Anbu only if
  the config allows it).
- **A** appoints (or removes) a **Village Advisor**: the person players should go to when they need help.
  Advisors' names are blue in the member list.
- **Village Storage**: a 54-slot chest shared by the village, opened from the Kage menu.

**Village Advisors** show as **[Advisor]** (and Kages as **[Kage]**) in front of their name in chat and the player
list (off unless `showKageTagInChat` is on), on the quest board, and on their own stats page. They come from the Kage
menu, `/shinobi advisor`, or the `.advisor` permission node.

### Ninja Bandits
Rogue ninja who roam the overworld in groups of 1-3, by day and night, anywhere with open sky. Each one uses a
nature: **Fire** (fireballs), **Water** (water bullets) or **Earth** (spikes from the ground under you). The colour
of their scarf and headband shows which. They cast from range and close in with a kunai. They drop 100-400 Ryo in coins
(more with Looting) and sometimes their kunai, and count toward bandit quests. There's a spawn egg in the
Naruto Generations creative tab.

## Jutsu voice lines

Every jutsu and eye technique has its own sound, played from the caster each time it goes off (on top of its effect
sounds). To add one, put a **mono OGG Vorbis** file with the right name in
`src/main/resources/assets/shinobiarts/sounds/voice/` (or the same path in a resource pack) and rebuild. Until a file is
there, that jutsu is silent; the game log lists the missing ones once at startup, which is harmless. Some jutsu share
a file: the three Wood Release jutsu play `voice/mokuton.ogg`, Shadow Clone and Multi Shadow Clone play
`voice/shadow_clone.ogg`, and Kamui and its snap play `voice/eye_kamui.ogg` (edit `assets/shinobiarts/sounds.json` to
split them). Outside the voice folder: `sounds/sharingan_on.ogg` (every Sharingan activation), `sounds/mangekyou_off.ogg`
(the eyes turning off after a Mangekyou) and `sounds/clone_poof.ogg` (shadow clones vanishing).

Already filled in: bansho_tenin, body_flicker, chibaku_tensei, chidori, eye_genjutsu, eye_kamui, hiding_in_ash,
majestic_destroyer_flame, mind_body_transfer, mokuton, rasengan, rasenshuriken, shadow_clone, shinra_tensei, water_clone.

To convert a clip: `ffmpeg -i clip.mp3 -ac 1 -c:a libvorbis -q:a 4 majestic_destroyer_flame.ogg`

File names:
- `voice/fireball.ogg`
- `voice/phoenix_flower.ogg`
- `voice/fire_annihilation.ogg`
- `voice/hiding_in_ash.ogg`
- `voice/majestic_destroyer_flame.ogg`
- `voice/water_bullet.ogg`
- `voice/water_prison.ogg`
- `voice/water_clone.ogg`
- `voice/water_shark.ogg`
- `voice/water_dragon.ogg`
- `voice/gale_palm.ogg`
- `voice/vacuum_blade.ogg`
- `voice/great_breakthrough.ogg`
- `voice/rasenshuriken.ogg`
- `voice/lightning_armor.ogg`
- `voice/chidori.ogg`
- `voice/thunder_strike.ogg`
- `voice/earth_wall.ogg`
- `voice/rock_armor.ogg`
- `voice/earth_spikes.ogg`
- `voice/hell_viewing.ogg`
- `voice/mind_fog.ogg`
- `voice/mystical_palm.ogg`
- `voice/vitality_surge.ogg`
- `voice/substitution.ogg`
- `voice/body_flicker.ogg`
- `voice/shadow_clone.ogg`
- `voice/rasengan.ogg`
- `voice/shadow_possession.ogg`
- `voice/palm_rotation.ogg`
- `voice/mokuton.ogg` (all three Wood Release jutsu)
- `voice/ice_needles.ogg`
- `voice/ice_prison.ogg`
- `voice/ice_mirrors.ogg`
- `voice/iron_sand_drizzle.ogg`
- `voice/iron_sand_coffin.ogg`
- `voice/iron_sand_world.ogg`
- `voice/finger_bullets.ogg`
- `voice/willow_dance.ogg`
- `voice/seedling_fern.ogg`
- `voice/barrier.ogg`
- `voice/adamantine_chains.ogg`
- `voice/five_elements_seal.ogg`
- `voice/shinra_tensei.ogg`
- `voice/bansho_tenin.ogg`
- `voice/chibaku_tensei.ogg`
- `voice/eye_amaterasu.ogg`
- `voice/eye_amaterasu_out.ogg`
- `voice/eye_kamui.ogg` (Kamui and its snap)
- `voice/eye_tsukuyomi.ogg`
- `voice/eye_blaze.ogg`
- `voice/eye_blaze_wall.ogg`
- `voice/eye_genjutsu.ogg`
- `voice/eye_palms_64.ogg`
- `voice/eye_air_palm.ogg`
- `voice/eye_all_seeing.ogg`

## Recipes (shapeless unless noted)

**Blank Scroll** = 3 paper + stick.

**Jutsu scrolls and releases can't be crafted** (since 1.9.0). Releases are handed over when you unlock the
nature or kekkei genkai; jutsu scrolls come from wherever the server hands them out (the shop's `stock` list in
General.toml can sell any of them, e.g. `"tools|shinobiarts:scroll_rasengan|1|5000"`, and `/give` works).

| Item | Recipe |
|---|---|
| Training Scroll | Blank Scroll + 3 of the nature's item + emerald |
| Frog Wallet | 2 leather + slime ball + lime dye + string |
| Kubikiribocho (shaped) | 2 iron blocks diagonally above a netherite ingot |
| Samehada (shaped) | heart of the sea, prismarine, netherite ingot on a diagonal (netherite at the bottom) |
| Hidan's Scythe (shaped) | 3 iron blocks across the top, netherite ingot in the middle, stick bottom-left |
| Sword of Fire (shaped) | gold block, netherite ingot, blaze rod on a diagonal (blaze rod at the bottom) |
| Shakujo Staff (shaped) | bell, gold block, gold block on a diagonal (bell at the top) |
| Kusanagi Sword (shaped) | 2 diamonds diagonally above a stick |
| Katana (shaped) | 2 iron ingots diagonally above a stick |
| Kiba Blades (shaped) | lightning rod, diamond block, stick on a diagonal (stick at the bottom) |
| Kabutowari (shaped) | iron axe, netherite ingot, anvil on a diagonal (anvil at the bottom) |
| Gunbai (shaped) | shield, netherite ingot, stick on a diagonal (stick at the bottom) |
| Kunai ×3 (shaped) | iron ingot diagonally above a stick |
| Shuriken ×4 (shaped) | iron ingot in a cross of 4 iron nuggets |
| Explosive Tag ×2 | paper + gunpowder + redstone |
| Chakra Pill ×2 | sugar + sweet berries + glowstone dust |
| Chakra Paper ×2 | paper + lapis lazuli |

Nature items: Fire = blaze powder, Water = prismarine shard, Wind = feather, Lightning = copper ingot,
Earth = clay ball, Yin Yang = amethyst shard, Ninjutsu = lapis lazuli, Wood = oak sapling, Ice = packed ice,
Magnet = iron nugget, Bone = bone, Sealing = chain.
Yin jutsu use fermented spider eyes, Yang jutsu use glistering melon; Ninjutsu and clan jutsu have special
recipes (see `tools/make_resources.py`).

## Admin commands (operators)

```
/shinobi info [player]
/shinobi xp <player> <amount>
/shinobi level <player> <level>
/shinobi rank <player> <genin|chunin|jonin|anbu|sannin>
/shinobi ryo <player> add|set <amount>
/shinobi release <player> <fire|water|wind|lightning|earth|yin_yang|ninjutsu>
/shinobi learn <player> <jutsu|all>        /shinobi forget <player> <jutsu|all>
/shinobi nature <player> <nature>          /shinobi clan <player> <clan>   (any of the 30; see /clan list)
/shinobi clanroll <player> reset           (gives a player their /clanroll uses back and unclaims their clan)
/shinobi refill <player>                   /shinobi reset <player>
/shinobi sharingan <player> <0-4>          (0 none, 1-3 tomoe, 4 Mangekyou)
/shinobi mangekyou <player> <itachi|sasuke|obito|eternal>   (gives the Mangekyou in that pattern)
/shinobi village <player> <village|none>   (puts a player in a village without a permission plugin)
/shinobi kage <player> <village|none>      (makes a player Kage; "none" removes the Kage title)
/shinobi advisor <player> <village|none>   (makes a player a Village Advisor; "none" removes it)
/shinobi jutsupoints <player> add|set <amount>
```

Everyone: `/clanroll`, `/clanroll claim`, `/vault`, `/team ...`, `/village`, `/village list`, `/clan`, `/clan list`, `/clan info <clan>`
(all blocked while in combat). XP Boost Tokens have no recipe yet: hand them out
with `/give <player> shinobiarts:xp_boost_2_5x_60m` (or `_1_5x_30m`, `_1_5x_60m`, `_2_5x_30m`).

Susanoo test: `/shinobi rank @s sannin`, `/shinobi level @s 250`, `/shinobi mangekyou @s eternal`, switch your eyes on
(**V**), then press **O** five times.

Quick test: `/shinobi learn @s all`, `/shinobi rank @s sannin`, `/shinobi level @s 20`, `/shinobi ryo @s add 5000`,
`/shinobi release @s fire`.

## Config

The files are in the game's config folder, `config/Naruto Generations/` (on a server, the server's `config` folder,
next to `fml.toml`): `Jutsus.toml`, `Weapons.toml`, `Food.toml`, `Stats.toml`, `Spawn weights and chances.toml` and
`General.toml`. They're created the first time the game or server starts with the mod, and a server sends its files
to every player who joins, so everyone plays by the server's values. Edit them with the server stopped (or restart it
afterwards so joining players get the new values). Together they hold XP curve, rank level caps, points and Ryo per level, every stat's value per point, the Speed cap,
reset cost, chakra regen, Senjutsu rates, Ninja Jump cost/power, damage and cooldown
multipliers, jutsu griefing, PvP rewards, each weapon's damage and special effect strength, jutsu chakra cost,
rank level requirements, mob XP, Sharingan stage levels and near-death health, eye theft, combat tag length,
command blocking, combat-log kills, team size, the village list, how many hourly/daily/weekly/monthly quests each
player gets, the Kage's reward caps and quest limit, whether a Kage can promote to Anbu, and the bandits' Ryo
drops and jutsu damage, how many times each player can use /clanroll, the chance of each clan rarity tier and whether rare rolls are announced, Jutsu Point chance/amount, upgrade cost, damage per upgrade and max upgrades, and whether
[Kage]/[Advisor] titles show in chat, every eye technique's cost, cooldown and range (`eyeTechniques`), Substitution's
jump and logs (`jutsuTuning`), and Chakra Control's drain and climb speed (`chakraControl`). Ninja Bandit spawning
(weight 10, groups of 1-3, all overworld biomes) and the DNA drops are in
`Spawn weights and chances.toml` (spawning changes need a restart).

## Art and models

- The Fire/Water/Wind/Lightning/Earth emblems, Amaterasu's black flames, the Great Fireball and Water Bullet sprites,
  Lightning Armor's sparks and the Sasuke/Obito/Eternal Mangekyou irises come from your asset pack
  (`tools/source_art/jutsu` and `tools/source_art/sharingan`). `python3 tools/import_jutsu_art.py` brings them in and
  also draws the Kamui/Genjutsu icons and the grey Sharingan of the empty dojutsu slot; then
  `python3 tools/make_sharingan.py` puts the Mangekyou patterns on the faces and the screen flash.
- The clan release emblems (木 氷 磁 骨 封) are drawn by `python3 tools/make_clan_releases.py`, in the same octagon
  style. Their blocks use vanilla textures (oak log, packed ice, black concrete powder, bone block).
- The Ninjutsu emblem is your picture (greyed, flames and tattoo removed). **The Yin Yang icon** can be replaced: save a square PNG as
  `src/main/resources/assets/shinobiarts/textures/nature/<yin_yang|ninjutsu>.png`, create an empty file
  `.<name>.provided` next to it, and run `python3 tools/make_textures.py` to rebuild the item icons.
- 3D models come from `tools/source_art/*.glb` and `tools/source_art/weapons/*.obj` (with their textures).
  `python3 tools/convert_models.py` turns them into Forge OBJ models: kunai, shuriken, the weapons, and the
  jutsu, training (地) and blank scrolls. The shuriken uses `source_art/shuriken_metal.png` because its own
  color is nearly black.
  `python3 tools/recolor_scrolls.py` then makes the jutsu scroll's color for each release.
  Samehada uses `source_art/samehada_recolor.png` (blue shark-skin scales, off-white bandages, blue grip), made by
  `python3 tools/recolor_samehada.py`. Its model tiles its texture, which Minecraft can't do, so the converter
  moves every triangle's texture coordinates back into range (that was what made it look glitchy).
  Each item holds exactly one scroll. The size of each weapon is its `length` in `MODELS`.
  Kiba, Kabutowari (axe and hammer, without the chain) and the Gunbai come from `tools/source_art/kiba.glb`,
  `kabutowari.glb` and `gunbai.glb`; their in-hand sizes are in `WEAPONS` / `OFFHAND_MODELS` in `tools/make_resources.py`.
- `python3 tools/make_jutsu_models.py` turns `tools/source_art/rasengan.glb` and `earth_spike_cluster.bbmodel` into the
  Rasengan and Rising Spikes meshes (`assets/shinobiarts/meshes/`) and their textures.
- `python3 tools/make_headbands.py` draws the forehead protector plates from the height maps of Calfan's headband model
  (`tools/source_art/headbands/`), plus the cloth and the inventory icons.
- Inventory icons stay flat so they're easy to read; the 3D model shows in your hand, on the ground and in flight.
  The kunai, shuriken, weapon and scroll icons are rendered from their 3D models
  (`tools/convert_models.py`, then `tools/recolor_scrolls.py` for the scroll colors).
- The chakra figure on the HUD is `source_art/chakra_figure.png` (cut out of your picture), saved small as
  `textures/gui/chakra_figure.png`. All Sharingan art (eyes on faces for each stage and pattern, the screen flash,
  the item icons, and the HUD's round eye icons) is drawn by `tools/make_sharingan.py`; the XP token icons
  by `tools/make_tokens.py`.
- Above the HUD scroll sits a row of slots: your eyes (Sharingan at its stage and pattern, or Byakugan, bright with a
  red or violet frame while active), the four armor pieces you're wearing with durability bars, and your eye
  techniques with their keys and cooldowns.

## Credits

These models are used under their Creative Commons licences (CC BY 4.0 unless noted), from Sketchfab:

| Model | Artist | Used for |
|---|---|---|
| Kiba | Nelesh_surve (sketchfab.com/Nelesh_surve) | Kiba Blades |
| Helmet Splitter (Kabutowari) - Naruto | Xnropa (sketchfab.com/sm3n26) | Kabutowari's axe and hammer |
| Gunbai Uchiwa | DontQuitIdol (sketchfab.com/fg2011) | Gunbai |
| Partical rasengan | OPREXT (sketchfab.com/OPREXT) | Rasengan |
| Naruto Headbands (CC BY-NC 4.0) | Calfan (sketchfab.com/Calfan) | Forehead protector plates |
| Zabuza Sword - Kubikiribocho | Ziof (sketchfab.com/fabri_iorio) | Kubikiribocho |
| Naruto Shippuden - Samehada | XDaniXSin (sketchfab.com/XDaniXSin) | Samehada (recoloured) |
| kunai | DMI (sketchfab.com/lord_DMI) | Kunai |
| Shuriken T0 | Clayton Creative (sketchfab.com/clayton_creative) | Shuriken (retextured) |
| Scrolls from Naruto | Viggo (sketchfab.com/Viggoa) | Jutsu, training and blank scrolls (recoloured) |
| Flying Thunder God Kunai : menato | DMI (sketchfab.com/lord_DMI), CC BY 4.0 | Flying Thunder God kunai (resized and posed for holding) |
| Naruto - Ataud Edo Tensei | GremorySaiyan (sketchfab.com/GremorySaiyan), CC BY 4.0 | Edo Tensei coffin (stood upright, scaled, lid split off on a hinge, texture resized) |

The models were converted for Minecraft (resized, posed for holding, textures baked or recoloured where noted).
The forehead protector plates are under a non-commercial licence, so this mod must not be sold or monetised while it
uses them. The Earth Flow Spike Cluster model was made for this mod.

## Saves

All player data lives in one place (`ninja/NinjaData.java`, changed only through
`ninja/PlayerDataManager.java`). It has a `DataVersion`; saves from the first version are upgraded
automatically: learned jutsu are kept, and old chakra training becomes stat points.

## Project layout

```
src/main/java/com/shinobiarts/
  ninja/      player data (NinjaData), PlayerDataManager, clans, natures, stats
  jutsu/      jutsu list, effects, casting, per-tick logic, key actions
  item/       releases, jutsu/training scrolls, coins, wallet, EXP bottle, weapons
  entity/     jutsu projectiles, thrown weapons, explosive tags, shadow clones
  client/     HUD, stats/reset/wallet screens, keybinds, renderers
  network/    key/menu requests (client -> server) and data sync (server -> client)
  command/    /shinobi
tools/        generators for icons, 3D models, models/recipes/lang (run with Python 3)
```

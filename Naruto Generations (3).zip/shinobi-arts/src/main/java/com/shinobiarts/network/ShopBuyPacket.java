package com.shinobiarts.network;

import com.shinobiarts.shop.Shop;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: buy entry {@code index} of the shop {@code times} times. */
public class ShopBuyPacket {
    private final int index, times;

    public ShopBuyPacket(int index, int times) {
        this.index = index;
        this.times = times;
    }

    public ShopBuyPacket(FriendlyByteBuf buf) {
        this.index = buf.readVarInt();
        this.times = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(index);
        buf.writeVarInt(times);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) Shop.buy(player, index, times);
    }
}

package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModDamage;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.UUID;

/**
 * The Eight Inner Gates, the taijutsu path for ninja without special eyes. The Eight Gates key (I) opens the next
 * gate; Sneak + the key closes them all. Each gate needs 10 more Taijutsu points (config) and adds speed, attack
 * speed, jump height and bare-hand damage. From the third gate on, holding them open costs health every second (never
 * enough to kill you: at half a heart the gates close themselves).
 * <p>
 * The eighth, the Gate of Death, lasts 20 seconds: press the key again for Night Guy, a dash that hits everything in
 * its path for massive damage. When it ends you're left at one heart, badly weakened for a minute, and the gates stay
 * locked for 10 minutes. The gates and the Susanoo can't be used together.
 */
public final class EightGates {
    private static final UUID SPEED_ID = UUID.fromString("4b8d2f6a-1c3e-4a5b-9d7f-2e4a6c8b0d71");
    private static final UUID ATTACK_SPEED_ID = UUID.fromString("7c1e3a5b-2d4f-4b6c-8e0a-3f5b7d9c1e82");
    private static final UUID STRENGTH_ID = UUID.fromString("2e6a8c0d-4f1b-4d3a-9c5e-7b9d1f3a5c64");
    /** The aura's colour at each gate (as in the show: pale chakra, the Gate of Life's red skin, green, blue, red steam). */
    public static final int[] AURA_RGB = {0, 0xBFE6FF, 0x8FF0C8, 0xFF7A4A, 0xFF9A2E, 0xFFD23A, 0x3FE86A, 0x3F8CFF, 0xE8141E};
    private static final float[] DRAIN = {0, 0, 0, 0.5f, 1f, 1.5f, 2f, 3f, 4f};   // health per second, by gate
    private static final String[] NAMES = {"", "opening", "healing", "life", "pain", "limit", "view", "wonder", "death"};

    private EightGates() {}

    public static Component gateName(int gate) {
        return Component.translatable("gate.shinobiarts." + NAMES[Math.max(1, Math.min(8, gate))]);
    }

    private static DustParticleOptions aura(int gate) {
        int c = AURA_RGB[Math.max(1, Math.min(8, gate))];
        return new DustParticleOptions(new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f),
                gate >= 8 ? 1.6f : gate >= 6 ? 1.4f : 1.1f);
    }

    /** The Eight Gates key: open the next gate (or Night Guy at the eighth); sneaking closes them all. */
    public static void key(ServerPlayer p, NinjaData d, boolean sneaking) {
        long now = p.level().getGameTime();
        if (sneaking) {
            if (d.getGatesOpen() > 0) close(p, d, true);
            return;
        }
        if (d.getGatesOpen() >= 8) {                     // Night Guy is on right-click now
            p.displayClientMessage(Component.translatable("message.shinobiarts.night_guy_hint").withStyle(ChatFormatting.RED), true);
            return;
        }
        if (d.getGatesLockedUntil() > now) {
            long left = (d.getGatesLockedUntil() - now) / 20;
            p.displayClientMessage(Component.translatable("message.shinobiarts.gates_locked", left / 60, String.format("%02d", left % 60))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        if (d.isStunned(now)) return;
        if (d.getSusanooStage() > 0) { // the gates and the Susanoo can't be used together
            p.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.gates_susanoo")
                    .withStyle(net.minecraft.ChatFormatting.RED), true);
            return;
        }
        if (Afflictions.isSealed(p)) { // Five Elements Seal / 64 Palms: the chakra won't flow
            Afflictions.canAct(p);
            return;
        }
        int next = d.getGatesOpen() + 1;
        int need = next * Config.i(Config.GATES_TAIJUTSU_PER_GATE);
        if (d.stat(Stat.TAIJUTSU) < need) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.gates_need_taijutsu", gateName(next), need, d.stat(Stat.TAIJUTSU))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        d.setGatesOpen(next);
        if (next == 2) p.heal(8f);                                    // the Gate of Healing
        if (next == 8) d.setGate8Until(now + Config.i(Config.GATE8_SECONDS) * 20L);
        applyModifiers(p, next);
        ServerLevel level = p.serverLevel();
        level.sendParticles(aura(next), p.getX(), p.getY() + 1, p.getZ(), 40 + next * 10, 0.5, 0.9, 0.5, 0.0);
        level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 12 + next * 3, 0.8, 0.1, 0.8, 0.08);
        JutsuUtil.sound(level, p.position(), SoundEvents.WARDEN_HEARTBEAT, 1.4f, 0.8f + next * 0.05f);
        if (next >= 6) JutsuUtil.sound(level, p.position(), SoundEvents.GENERIC_EXPLODE, 0.6f, 1.6f);
        p.displayClientMessage(Component.translatable(next == 8 ? "message.shinobiarts.gate8_open" : "message.shinobiarts.gate_open",
                gateName(next), next).withStyle(next >= 8 ? ChatFormatting.RED : next >= 6 ? ChatFormatting.GREEN : ChatFormatting.AQUA), true);
        ModNetwork.sync(p);
        com.shinobiarts.ninja.SharinganManager.updateLook(p);   // everyone sees the aura (and the veins) change
    }

    /** Speed and attack speed for the open gates (transient: gone after relogging, when the gates are closed anyway). */
    private static void applyModifiers(ServerPlayer p, int gates) {
        AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
            if (gates > 0) speed.addTransientModifier(new AttributeModifier(SPEED_ID, "Eight Gates speed",
                    gates * Config.d(Config.GATES_SPEED_PER_GATE) + (gates >= 8 ? 0.6 : 0), AttributeModifier.Operation.MULTIPLY_BASE));
        }
        AttributeInstance attack = p.getAttribute(Attributes.ATTACK_SPEED);
        if (attack != null) {
            attack.removeModifier(ATTACK_SPEED_ID);
            if (gates > 0) attack.addTransientModifier(new AttributeModifier(ATTACK_SPEED_ID, "Eight Gates attack speed",
                    gates * Config.d(Config.GATES_ATTACK_SPEED_PER_GATE), AttributeModifier.Operation.MULTIPLY_BASE));
        }
        AttributeInstance strength = p.getAttribute(Attributes.ATTACK_DAMAGE);
        if (strength != null) {
            strength.removeModifier(STRENGTH_ID);
            if (gates > 0) strength.addTransientModifier(new AttributeModifier(STRENGTH_ID, "Eight Gates strength",
                    gates * Config.d(Config.GATES_STRENGTH_PER_GATE) * (gates >= 8 ? 2 : 1), AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    /** Share of incoming damage the open gates' hardened body shrugs off (capped at 60%). */
    public static float resistance(NinjaData d) {
        int g = d.getGatesOpen();
        return g <= 0 ? 0f : Math.min(0.6f, g * Config.f(Config.GATES_RESISTANCE_PER_GATE));
    }

    /** Extra bare-hand damage from the open gates (added in the damage event). */
    public static float punchBonus(NinjaData d) {
        int g = d.getGatesOpen();
        return g <= 0 ? 0f : g * Config.f(Config.GATES_DAMAGE_PER_GATE) * (g >= 8 ? 2f : 1f);
    }

    /** Closes every gate. After the Gate of Death: one heart left, weakened for a minute, gates locked for a while. */
    public static void close(ServerPlayer p, NinjaData d, boolean byKey) {
        int was = d.getGatesOpen();
        if (was <= 0) return;
        d.setGatesOpen(0);
        d.setGate8Until(0);
        applyModifiers(p, 0);
        if (was >= 8 && Config.b(Config.GATE8_KILLS)) {
            // the Gate of Death takes its price: the body burns itself out
            p.serverLevel().sendParticles(aura(8), p.getX(), p.getY() + 1, p.getZ(), 120, 0.5, 0.9, 0.5, 0.0);
            p.serverLevel().sendParticles(ParticleTypes.ASH, p.getX(), p.getY() + 1, p.getZ(), 80, 0.4, 0.8, 0.4, 0.02);
            ModNetwork.sync(p);
            com.shinobiarts.ninja.SharinganManager.updateLook(p);
            net.minecraft.world.damagesource.DamageSource death = ModDamage.gateOfDeath(p.level());
            p.hurt(death, Float.MAX_VALUE);
            if (p.isAlive()) {                           // something stepped in: the gate still wins
                p.setHealth(0f);
                p.die(death);
            }
            return;
        }
        if (was >= 8) {
            if (p.getHealth() > 2f) p.setHealth(2f);
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 1200, 2));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 1200, 2));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 1200, 1));
            d.setGatesLockedUntil(p.level().getGameTime() + Config.i(Config.GATES_LOCK_MINUTES) * 1200L);
            p.displayClientMessage(Component.translatable("message.shinobiarts.gate8_end").withStyle(ChatFormatting.DARK_RED), false);
        } else if (was >= 5) {
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, was * 80, 0));        // sore muscles
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, was * 80, 0));
        }
        if (byKey || was < 8) p.displayClientMessage(Component.translatable("message.shinobiarts.gates_closed").withStyle(ChatFormatting.GRAY), true);
        p.serverLevel().sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 20, 0.4, 0.6, 0.4, 0.02);
        ModNetwork.sync(p);
        com.shinobiarts.ninja.SharinganManager.updateLook(p);
    }

    /** Right-click with the Eighth Gate open: Night Guy. */
    public static void rightClick(ServerPlayer p, NinjaData d) {
        if (d.getGatesOpen() >= 8 && p.isAlive() && !d.isStunned(p.level().getGameTime())) nightGuy(p, d);
    }

    /**
     * From the Third Gate on, Ninja Jump is a burst of speed too fast to see: you vanish and reappear up to 9 blocks
     * ahead (further with each gate), along where you look, stopping short of walls.
     */
    public static boolean blink(ServerPlayer p, NinjaData d) {
        int g = d.getGatesOpen();
        if (g < 3) return false;
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, Math.max(-0.35, Math.min(0.6, look.y)), look.z).normalize();
        double max = 6 + g * 1.5;
        Vec3 from = p.position().add(0, 0.9, 0);
        BlockHitResult wall = level.clip(new ClipContext(from, from.add(dir.scale(max)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double length = wall.getType() == HitResult.Type.MISS ? max : Math.max(0, wall.getLocation().distanceTo(from) - 0.7);
        Vec3 end = null;
        for (double t = length; t >= 0.5; t -= 0.5) {                 // the furthest spot you'd fit
            Vec3 feet = from.add(dir.scale(t)).subtract(0, 0.9, 0);
            if (level.noCollision(p, p.getDimensions(p.getPose()).makeBoundingBox(feet))) {
                end = feet;
                break;
            }
        }
        if (end == null) return false;
        Vec3 start = p.position();
        DustParticleOptions dust = aura(g);
        level.sendParticles(dust, start.x, start.y + 1, start.z, 30, 0.35, 0.8, 0.35, 0.0);
        level.sendParticles(ParticleTypes.CLOUD, start.x, start.y + 0.2, start.z, 14, 0.4, 0.1, 0.4, 0.12);
        for (double t = 0; t < 1; t += 0.08) {
            Vec3 q = start.lerp(end, t);
            level.sendParticles(dust, q.x, q.y + 1, q.z, 1, 0.1, 0.25, 0.1, 0.0);
        }
        JutsuUtil.teleport(p, end);
        p.setDeltaMovement(p.getDeltaMovement().multiply(1, 0, 1).add(0, 0.25, 0));
        p.hurtMarked = true;
        p.resetFallDistance();
        d.setFallProtectUntil(level.getGameTime() + 60);
        level.sendParticles(dust, end.x, end.y + 1, end.z, 30, 0.35, 0.8, 0.35, 0.0);
        level.sendParticles(ParticleTypes.CLOUD, end.x, end.y + 0.2, end.z, 10, 0.4, 0.1, 0.4, 0.08);
        JutsuUtil.sound(level, start, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 1.9f);
        JutsuUtil.sound(level, end, SoundEvents.ENDER_DRAGON_FLAP, 0.6f, 1.8f);
        return true;
    }

    /** Night Guy: a dash of up to 16 blocks along your line of sight that hits everything in its path. Ends gate 8. */
    private static void nightGuy(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 start = p.position().add(0, 0.1, 0);
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, Math.max(-0.4, Math.min(0.4, look.y)), look.z).normalize();
        BlockHitResult wall = level.clip(new ClipContext(start.add(0, 1, 0), start.add(0, 1, 0).add(dir.scale(16)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double length = wall.getType() == HitResult.Type.MISS ? 16 : Math.max(0, wall.getLocation().distanceTo(start.add(0, 1, 0)) - 0.8);
        Vec3 end = start.add(dir.scale(length));
        float damage = Config.f(Config.NIGHT_GUY_DAMAGE);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().expandTowards(dir.scale(length)).inflate(2.0),
                cand -> JutsuUtil.isValidTarget(p, cand))) {
            Vec3 c = e.getBoundingBox().getCenter();
            Vec3 rel = c.subtract(start.add(0, 1, 0));
            double along = rel.dot(dir);
            if (along < -1 || along > length + 1.5 || rel.subtract(dir.scale(along)).length() > 2.2) continue;
            e.invulnerableTime = 0;
            e.hurt(ModDamage.jutsu(level, p, p), damage);
            JutsuUtil.push(e, dir.scale(2.5).add(0, 0.6, 0));
        }
        for (double t = 0; t <= length; t += 0.5) {                     // the red dragon of steam along the path
            Vec3 q = start.add(dir.scale(t));
            double a = t * 1.3;
            level.sendParticles(aura(8), q.x + Math.cos(a) * 0.9, q.y + 1 + Math.sin(a) * 0.9, q.z, 4, 0.15, 0.15, 0.15, 0.0);
            level.sendParticles(ParticleTypes.CLOUD, q.x, q.y + 1, q.z, 1, 0.2, 0.2, 0.2, 0.02);
        }
        JutsuUtil.teleport(p, end);
        p.resetFallDistance();
        JutsuUtil.sound(level, end, SoundEvents.ENDER_DRAGON_GROWL, 1.0f, 1.3f);
        JutsuUtil.sound(level, end, SoundEvents.GENERIC_EXPLODE, 1.2f, 0.7f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.night_guy").withStyle(ChatFormatting.RED), true);
        close(p, d, false);
    }

    /** Every tick while gates are open: aura, jump boost, health drain, the eighth gate's timer. */
    public static void tick(ServerPlayer p, NinjaData d, long now) {
        int g = d.getGatesOpen();
        if (g <= 0) return;
        ServerLevel level = p.serverLevel();
        if (p.tickCount % 2 == 0) {
            level.sendParticles(aura(g), p.getX(), p.getY() + 0.9, p.getZ(), 1 + g / 2, 0.35, 0.6, 0.35, 0.0);
            if (g >= 8) level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0.3, 0.5, 0.3, 0.01);
            else if (g >= 7) level.sendParticles(ParticleTypes.FALLING_WATER, p.getX(), p.getY() + 1.2, p.getZ(), 1, 0.3, 0.5, 0.3, 0.0);
        }
        if (p.tickCount % 20 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.JUMP, 40, Math.min(4, (g + 1) / 2), false, false, true));
            float drain = DRAIN[g] * Config.f(Config.GATES_DRAIN_MULTIPLIER);
            if (drain > 0 && !p.getAbilities().instabuild) {
                if (p.getHealth() - drain < 1f && g < 8) {
                    close(p, d, false);                                  // the body gives out before it breaks
                    return;
                }
                p.setHealth(Math.max(1f, p.getHealth() - drain));
            }
        }
        if (g >= 8 && d.getGate8Until() != 0 && now >= d.getGate8Until()) close(p, d, false);
    }
}

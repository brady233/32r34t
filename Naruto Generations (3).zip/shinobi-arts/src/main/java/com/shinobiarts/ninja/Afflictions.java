package com.shinobiarts.ninja;

import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

/**
 * Being frozen (stunned) or having your chakra points sealed, for players and creatures alike.
 * <ul>
 *   <li>Stunned (Tsukuyomi...): can't move, attack, or use jutsu and eye techniques. Players keep it in their ninja data
 *       (so their own client can freeze their movement and draw the effect); creatures in their persistent data,
 *       plus maximum Slowness so they stand still.</li>
 *   <li>Sealed (Eight Trigrams 64 Palms...): can't use jutsu, eye techniques or the Susanoo.</li>
 * </ul>
 */
public final class Afflictions {
    public static final int STUN_NONE = 0;
    public static final int STUN_TSUKUYOMI = 1;

    private static final String STUN_KEY = "shinobiarts.stunUntil";
    private static final String SEAL_KEY = "shinobiarts.sealedUntil";

    private Afflictions() {}

    public static void stun(LivingEntity e, int ticks, int kind) {
        long until = e.level().getGameTime() + ticks;
        if (e instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d != null) {
                d.setStun(Math.max(until, d.getStunUntil()), kind);
                if (d.isCharging()) d.setCharging(false);
                ModNetwork.sync(p);
            }
        } else {
            e.getPersistentData().putLong(STUN_KEY, Math.max(until, e.getPersistentData().getLong(STUN_KEY)));
            if (e instanceof Mob mob) mob.getNavigation().stop();
        }
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 9, false, false, true));
    }

    /** Ends a stun early (a Water Prison bursting): the creature can move and act again straight away. */
    public static void unstun(LivingEntity e) {
        if (!isStunned(e)) return;
        if (e instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d != null) {
                d.setStun(0, STUN_NONE);
                ModNetwork.sync(p);
            }
        } else {
            e.getPersistentData().remove(STUN_KEY);
        }
        MobEffectInstance slow = e.getEffect(MobEffects.MOVEMENT_SLOWDOWN);
        if (slow != null && slow.getAmplifier() == 9) e.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
    }

    public static boolean isStunned(LivingEntity e) {
        long now = e.level().getGameTime();
        if (e instanceof Player p) {
            NinjaData d = NinjaData.get(p);
            return d != null && d.isStunned(now);
        }
        return e.getPersistentData().getLong(STUN_KEY) > now;
    }

    public static void seal(LivingEntity e, int ticks) {
        long until = e.level().getGameTime() + ticks;
        if (e instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d != null) {
                d.setSealedUntil(Math.max(until, d.getSealedUntil()));
                ModNetwork.sync(p);
            }
        } else {
            e.getPersistentData().putLong(SEAL_KEY, Math.max(until, e.getPersistentData().getLong(SEAL_KEY)));
        }
    }

    public static boolean isSealed(LivingEntity e) {
        long now = e.level().getGameTime();
        if (e instanceof Player p) {
            NinjaData d = NinjaData.get(p);
            return d != null && d.isSealed(now);
        }
        return e.getPersistentData().getLong(SEAL_KEY) > now;
    }

    /**
     * Whether a player may use a jutsu / eye technique right now; if not, tells them why (on the action bar).
     */
    public static boolean canAct(ServerPlayer p) {
        if (isStunned(p)) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.stunned").withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        if (isSealed(p)) {
            NinjaData d = NinjaData.get(p);
            long left = d == null ? 0 : Math.max(0, d.getSealedUntil() - p.level().getGameTime());
            p.displayClientMessage(Component.translatable("message.shinobiarts.chakra_sealed", String.format("%.0f", Math.ceil(left / 20.0)))
                    .withStyle(ChatFormatting.DARK_PURPLE), true);
            return false;
        }
        return true;
    }
}

package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import javax.annotation.Nullable;

/**
 * The nine tailed beasts. Each has its chakra's colour (its cloak and shroud), the darker colour of its Version 2
 * shroud and what grows on the shroud's head (ears or horns).
 */
public enum TailedBeast {
    SHUKAKU(1, "shukaku", "One-Tails", 0xD8B26A, 0x6A4A20, HeadShape.ROUND_EARS),
    MATATABI(2, "matatabi", "Two-Tails", 0x3A7BFF, 0x101E5A, HeadShape.CAT_EARS),
    ISOBU(3, "isobu", "Three-Tails", 0x7FB09A, 0x1E3A30, HeadShape.SPIKES),
    SON_GOKU(4, "son_goku", "Four-Tails", 0xE0452A, 0x5A140C, HeadShape.HORNS),
    KOKUO(5, "kokuo", "Five-Tails", 0xF2EEE0, 0x6A6458, HeadShape.HORNS),
    SAIKEN(6, "saiken", "Six-Tails", 0xCFE8B0, 0x4A5A3A, HeadShape.NONE),
    CHOMEI(7, "chomei", "Seven-Tails", 0x7CD84A, 0x22501A, HeadShape.ANTENNAE),
    GYUKI(8, "gyuki", "Eight-Tails", 0x9A7CB8, 0x2E2238, HeadShape.OX_HORNS),
    KURAMA(9, "kurama", "Nine-Tails", 0xFF7A1A, 0x5A1206, HeadShape.FOX_EARS);

    /** What sits on a chakra shroud's head. */
    public enum HeadShape { NONE, ROUND_EARS, CAT_EARS, FOX_EARS, HORNS, OX_HORNS, ANTENNAE, SPIKES }

    public final int tails;
    public final String id;
    public final String title;
    public final int color, dark;
    public final HeadShape head;

    TailedBeast(int tails, String id, String title, int color, int dark, HeadShape head) {
        this.tails = tails;
        this.id = id;
        this.title = title;
        this.color = color;
        this.dark = dark;
        this.head = head;
    }

    public MutableComponent displayName() {
        return Component.translatable("beast.shinobiarts." + id).withStyle(ChatFormatting.GOLD);
    }

    /** The highest tail count of the uncontrollable rage forms: up to six (fewer for beasts with fewer tails). */
    public int maxRage() {
        return Math.min(6, tails);
    }

    @Nullable
    public static TailedBeast byId(String id) {
        for (TailedBeast b : values()) if (b.id.equals(id) || String.valueOf(b.tails).equals(id)) return b;
        return null;
    }

    @Nullable
    public static TailedBeast byTails(int tails) {
        return tails >= 1 && tails <= 9 ? values()[tails - 1] : null;
    }
}

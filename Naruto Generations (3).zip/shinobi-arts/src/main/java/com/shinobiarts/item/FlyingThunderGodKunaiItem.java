package com.shinobiarts.item;

import com.shinobiarts.entity.FtgKunaiEntity;
import com.shinobiarts.ninja.FlyingThunderGod;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Minato's Flying Thunder God kunai (three-pronged, the seal formula on its handle):
 * <ul>
 *   <li>Right-click a block: write the Flying Thunder God seal on it (sneak: wipe a seal of yours off).</li>
 *   <li>Right-click toward one of your marks: flash there.</li>
 *   <li>Right-click anywhere else: throw it. It marks wherever it sticks, and anyone it hits.</li>
 *   <li>Hitting someone with it marks them too.</li>
 * </ul>
 */
public class FlyingThunderGodKunaiItem extends ThrownToolItem {
    public FlyingThunderGodKunaiItem(Properties properties) {
        super(properties, 2.4f, 12, 5.0, -2.0);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getPlayer() instanceof ServerPlayer sp) FlyingThunderGod.seal(sp, ctx.getClickedPos(), ctx.getClickedFace());
        return InteractionResult.sidedSuccess(ctx.getLevel().isClientSide);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        ServerPlayer sp = (ServerPlayer) player;
        NinjaData d = NinjaData.get(sp);
        if (d == null || !FlyingThunderGod.canUse(sp, d, true)) return InteractionResultHolder.fail(stack);
        FlyingThunderGod.Mark aimed = FlyingThunderGod.aimed(sp, d);
        if (aimed != null) {                                       // flash to the mark you're looking at
            FlyingThunderGod.teleport(sp, d, aimed);
            return InteractionResultHolder.success(stack);
        }
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 0.6f, 1.5f);
        FtgKunaiEntity kunai = new FtgKunaiEntity(level, player);
        kunai.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 2.6f, 0.4f);
        level.addFreshEntity(kunai);
        player.getCooldowns().addCooldown(this, 12);
        player.awardStat(Stats.ITEM_USED.get(this));
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.success(stack);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof ServerPlayer sp) FlyingThunderGod.markTarget(sp, target);
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.ftg_seal").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.shinobiarts.ftg_throw").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.shinobiarts.ftg_teleport").withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.translatable("tooltip.shinobiarts.ftg_menu").withStyle(ChatFormatting.GRAY));
    }
}

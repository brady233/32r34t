package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;

import javax.annotation.Nullable;

/** Validates and performs a cast of the selected jutsu in the release the player is holding. */
public final class JutsuCaster {
    private JutsuCaster() {}

    public static void tryCast(ServerPlayer player) {
        tryCast(player, ReleaseItem.heldRelease(player), InteractionHand.MAIN_HAND);
    }

    /** Casts the selected jutsu of a release at normal power (right-clicking a jutsu that doesn't charge). */
    public static void tryCast(ServerPlayer player, @Nullable ChakraNature release, InteractionHand hand) {
        tryCast(player, release, hand, 1f);
    }

    /** Casts after holding right-click for {@code ticksHeld}: the longer the charge, the stronger the jutsu. */
    public static void castCharged(ServerPlayer player, @Nullable ChakraNature release, InteractionHand hand, int ticksHeld) {
        NinjaData data = NinjaData.get(player);
        Jutsu jutsu = data == null || release == null ? null : data.selectedJutsu(release);
        if (jutsu == null) {
            tryCast(player, release, hand, 1f);
            return;
        }
        tryCast(player, release, hand, JutsuCharge.power(jutsu, ticksHeld), JutsuCharge.fraction(jutsu, ticksHeld),
                JutsuCharge.size(jutsu, ticksHeld));
    }

    /** Casts the selected jutsu of a release; {@code power} scales its damage (charging). */
    public static void tryCast(ServerPlayer player, @Nullable ChakraNature release, InteractionHand hand, float power) {
        tryCast(player, release, hand, power, -1f);
    }

    /** As above; {@code charge} is how charged it was (0 tap .. 1 full, -1 = not charged), which sizes the Great Fireball. */
    public static void tryCast(ServerPlayer player, @Nullable ChakraNature release, InteractionHand hand, float power, float charge) {
        tryCast(player, release, hand, power, charge, 1f);
    }

    /** As above; {@code size} (1 or more) is how much an overcharge enlarges it, and raises its chakra cost. */
    public static void tryCast(ServerPlayer player, @Nullable ChakraNature release, InteractionHand hand, float power, float charge,
                               float size) {
        NinjaData data = NinjaData.get(player);
        if (data == null || player.isSpectator() || !player.isAlive()) return;
        if (!com.shinobiarts.ninja.Afflictions.canAct(player)) return; // frozen, or chakra points sealed

        if (release == null) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.hold_release").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (!data.hasNature(release)) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.release_locked", release.displayName()).withStyle(ChatFormatting.RED), true);
            return;
        }
        Jutsu jutsu = data.selectedJutsu(release);
        if (jutsu == null) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.release_empty", release.displayName()).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (com.shinobiarts.Config.banned(jutsu.id())) {               // the server has banned it
            player.displayClientMessage(Component.translatable("message.shinobiarts.jutsu_banned", jutsu.displayName()).withStyle(ChatFormatting.RED), true);
            return;
        }

        long now = player.level().getGameTime();
        long remaining = data.cooldownRemaining(jutsu.id(), now);
        if (remaining > 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.cooldown", jutsu.displayName(),
                    String.format("%.1f", remaining / 20.0f)).withStyle(ChatFormatting.GRAY), true);
            return;
        }

        if (Jutsus.isRinnegan(jutsu) && !data.hasRinnegan()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.need_rinnegan").withStyle(ChatFormatting.RED), true);
            return;
        }
        if (jutsu.needsDojutsu() && !data.isMangekyouActive()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.needs_mangekyou").withStyle(ChatFormatting.RED), true);
            return;
        }

        boolean creative = player.getAbilities().instabuild;
        float cost = jutsu.cost(data) * (1f + Math.max(0f, size - 1f) * com.shinobiarts.Config.f(com.shinobiarts.Config.OVERCHARGE_CHAKRA));
        if (!creative && data.getChakra() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) data.getChakra(), (int) Math.ceil(cost)).withStyle(ChatFormatting.RED), true);
            player.playNotifySound(SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.4f, 1.8f);
            return;
        }

        // upgrades and clan bonuses (e.g. Uchiha +20% Fire) scale every dmg() call made during the cast
        // the jutsu's own damage multiplier from the config too; and remember it for death messages ("killed by Chidori")
        JutsuUtil.noteCast(player, jutsu);
        if (!JutsuUtil.withCast(data.jutsuBonus(jutsu) * jutsu.damageMultiplier() * power, charge, size,
                () -> jutsu.action().perform(player, data))) return;

        if (!creative) data.consumeChakra(cost);
        data.setCooldown(jutsu.id(), now + jutsu.cooldownFor(data));
        com.shinobiarts.registry.ModSounds.jutsu(player, jutsu.id());        // its voice line, if one has been added
        player.swing(hand, true);
        player.displayClientMessage(jutsu.displayName(), true);
        ModNetwork.sync(player);

        sharinganCopy(player, jutsu);
        com.shinobiarts.entity.ShadowClone.copyOwnerJutsu(player, jutsu.id()); // clones copy hand jutsu
    }

    /**
     * Uchiha with an active Sharingan who watch someone cast a jutsu learn it instantly (not clan techniques: those,
     * Wood Release included, can't be copied).
     */
    private static void sharinganCopy(ServerPlayer caster, Jutsu jutsu) {
        if (jutsu.clan() != null || jutsu.needsDojutsu()) return;
        for (ServerPlayer watcher : caster.serverLevel().players()) {
            if (watcher == caster) continue;
            NinjaData data = NinjaData.get(watcher);
            if (data == null || !data.isSharinganActive() || data.knows(jutsu.id())) continue;
            double range = SharinganManager.copyRange(data);
            if (watcher.distanceToSqr(caster) > range * range || !watcher.hasLineOfSight(caster)) continue;
            data.learn(jutsu.id());
            watcher.sendSystemMessage(Component.translatable("message.shinobiarts.sharingan_copy", jutsu.displayName())
                    .withStyle(ChatFormatting.DARK_RED));
            watcher.playNotifySound(SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 0.8f);
            ModNetwork.sync(watcher);
        }
    }
}

package com.shinobiarts.jutsu;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.network.WaterPrisonPacket;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.registry.ModDamage;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Water Prison: a sphere of swirling water closes around the target and drags it to the caster, who holds it with
 * an outstretched arm (Zabuza's pose) for as long as they hold right-click, paying chakra every second. Inside, the
 * target can't move or act, its air runs out and it takes damage every second. The caster can only shuffle slowly
 * while holding it (the prison stays at their hand); running out of chakra bursts it. Very large creatures (taller than 3.2 blocks) are caught where they stand instead.
 * Clients draw the sphere and the caster's arm (client/WaterPrisonRender).
 */
public final class WaterPrison {
    /** Ticks the target takes to be dragged over to the caster. */
    public static final int PULL_TICKS = 8;

    private static final class Hold {
        final int targetId;
        final long start, until;
        final Vec3 from;          // where the target was caught (its feet)
        final Vec3 casterPos;
        final float radius, damagePerSecond;
        final boolean pull;

        Hold(int targetId, long start, long until, Vec3 from, Vec3 casterPos, float radius, float damagePerSecond, boolean pull) {
            this.targetId = targetId;
            this.start = start;
            this.until = until;
            this.from = from;
            this.casterPos = casterPos;
            this.radius = radius;
            this.damagePerSecond = damagePerSecond;
            this.pull = pull;
        }
    }

    private static final Map<UUID, Hold> HOLDS = new HashMap<>();

    private WaterPrison() {}

    /** Radius of the sphere around a creature this size (a player gets about 1.7). */
    public static float radiusFor(LivingEntity target) {
        return Math.max(target.getBbWidth(), target.getBbHeight()) * 0.62f + 0.55f;
    }

    /** Traps the target for {@code ticks} ticks, dealing {@code damagePerSecond} every second. */
    public static void start(ServerPlayer caster, LivingEntity target, int ticks, float damagePerSecond) {
        end(caster, false);
        long now = caster.level().getGameTime();
        float radius = radiusFor(target);
        boolean pull = target.getBbHeight() <= 3.2f;
        HOLDS.put(caster.getUUID(), new Hold(target.getId(), now, now + ticks, target.position(), caster.position(), radius,
                damagePerSecond, pull));
        Afflictions.stun(target, 10, Afflictions.STUN_NONE);           // kept up every tick while it's held
        target.clearFire();
        if (target instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setTarget(null);
        }
        send(caster, target, ticks, radius);
    }

    /** Where the target's feet are held: in front of the caster's outstretched hand (or where it was caught). */
    private static Vec3 heldFeet(ServerPlayer caster, LivingEntity target, Hold h) {
        if (!h.pull) return h.from;
        float yaw = caster.getYRot() * Mth.DEG_TO_RAD;
        Vec3 forward = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 centre = caster.position().add(0, 1.3, 0).add(forward.scale(h.radius + 0.7));
        return centre.subtract(0, target.getBbHeight() / 2.0, 0);
    }

    /** Lets go: the caster cast again, moved, died or logged out, or the time ran out. A burst splashes. */
    public static void end(ServerPlayer caster, boolean burst) {
        Hold h = HOLDS.remove(caster.getUUID());
        if (h == null) return;
        Entity t = caster.level().getEntity(h.targetId);
        send(caster, t, 0, h.radius);
        if (t instanceof LivingEntity target) {
            Afflictions.unstun(target);
            ServerLevel level = caster.serverLevel();
            Vec3 c = target.getBoundingBox().getCenter();
            level.sendParticles(ParticleTypes.SPLASH, c.x, c.y, c.z, burst ? 160 : 90, h.radius * 0.6, h.radius * 0.6, h.radius * 0.6, 0.3);
            level.sendParticles(ParticleTypes.FALLING_WATER, c.x, c.y, c.z, 40, h.radius * 0.7, h.radius * 0.5, h.radius * 0.7, 0.0);
            level.playSound(null, c.x, c.y, c.z, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, SoundSource.PLAYERS, 1.0f, 0.8f);
        }
    }

    public static boolean isHolding(ServerPlayer caster) {
        return HOLDS.containsKey(caster.getUUID());
    }

    private static void send(ServerPlayer caster, Entity target, int ticks, float radius) {
        WaterPrisonPacket packet = new WaterPrisonPacket(caster.getId(), target == null ? -1 : target.getId(), ticks, radius);
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> caster), packet);
        if (target instanceof ServerPlayer tp) ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> tp), packet);
    }

    /** Every tick for the caster (from the ninja ticker). */
    public static void tick(ServerPlayer caster) {
        Hold h = HOLDS.get(caster.getUUID());
        if (h == null) return;
        ServerLevel level = caster.serverLevel();
        long now = level.getGameTime();
        Entity e = level.getEntity(h.targetId);
        if (!(e instanceof LivingEntity target) || !target.isAlive() || !caster.isAlive() || now >= h.until) {
            end(caster, false);
            return;
        }
        // held: it ends when right-click comes up (ReleaseItem.releaseUsing, or the client's HOLD_RELEASED) or the
        // release is put away; nothing else about the item use is trusted, so it can't drop early
        if (now - h.start > 2 && com.shinobiarts.item.ReleaseItem.heldRelease(caster) == null) {
            end(caster, false);
            return;
        }
        if ((now - h.start) % 20 == 19 && !caster.getAbilities().instabuild) {     // the chakra it takes to hold it
            com.shinobiarts.ninja.NinjaData d = com.shinobiarts.ninja.NinjaData.get(caster);
            if (d != null) {
                float cost = d.maxChakra() * com.shinobiarts.Config.f(com.shinobiarts.Config.WATER_PRISON_DRAIN);
                if (d.getChakra() < cost) {
                    caster.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.water_prison_chakra")
                            .withStyle(net.minecraft.ChatFormatting.RED), true);
                    end(caster, true);
                    return;
                }
                d.consumeChakra(cost);
                ModNetwork.sync(caster);
            }
        }
        Afflictions.stun(target, 10, Afflictions.STUN_NONE);
        // the caster can only shuffle while holding it; the prison stays at their hand wherever they go
        caster.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 5, 3, false, false, false));

        // drag it over, then hold it still in the middle of the sphere
        float t = Mth.clamp((now - h.start) / (float) PULL_TICKS, 0f, 1f);
        t = t * t * (3 - 2 * t);
        Vec3 goal = heldFeet(caster, target, h);
        Vec3 pos = h.from.lerp(goal, t);
        if (target instanceof ServerPlayer tp) {
            if (tp.position().distanceToSqr(pos) > 0.04) tp.connection.teleport(pos.x, pos.y, pos.z, tp.getYRot(), tp.getXRot());
        } else {
            target.setPos(pos.x, pos.y, pos.z);
            if (target instanceof Mob mob) mob.getNavigation().stop();
        }
        target.setDeltaMovement(Vec3.ZERO);
        target.resetFallDistance();
        target.clearFire();

        // it can't breathe: its air drains (the bubbles show it), and it takes damage every second
        if (!target.canBreatheUnderwater()) target.setAirSupply(Math.max(-20, target.getAirSupply() - 7));
        if ((now - h.start) % 20 == 19) {
            float dmg = h.damagePerSecond * (target.getAirSupply() <= 0 && !target.canBreatheUnderwater() ? 1.5f : 1f);
            target.hurt(ModDamage.jutsu(level, caster, caster), dmg);
            target.setDeltaMovement(Vec3.ZERO);
        }
        Vec3 c = target.getBoundingBox().getCenter();
        if (now % 3 == 0) {
            level.sendParticles(ParticleTypes.BUBBLE_POP, c.x, c.y, c.z, 3, h.radius * 0.5, h.radius * 0.5, h.radius * 0.5, 0.02);
            level.sendParticles(ParticleTypes.DRIPPING_WATER, c.x, c.y - h.radius * 0.8, c.z, 2, h.radius * 0.5, 0.05, h.radius * 0.5, 0.0);
        }
        if (now % 30 == 0) level.playSound(null, c.x, c.y, c.z, SoundEvents.WATER_AMBIENT, SoundSource.PLAYERS, 0.8f, 0.9f);
    }

    /** Forgets everything (server stopping). */
    public static void clearAll() {
        HOLDS.clear();
    }
}

package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.pvp.ShinobiRecords;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * Bounties: /bounty &lt;player&gt; &lt;ryo&gt; puts Ryo on someone's head (whoever kills them takes it all); /bounty list shows
 * who's wanted. The whole board, as ninja info cards, is on the Bounties page of the ninja menu.
 */
public final class BountyCommand {
    private BountyCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("bounty")
                .then(Commands.literal("list").executes(ctx -> list(ctx.getSource())))
                .then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("ryo", LongArgumentType.longArg(1))
                                .executes(ctx -> {
                                    ServerPlayer by = ctx.getSource().getPlayerOrException();
                                    ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                                    return ShinobiRecords.post(by, target, LongArgumentType.getLong(ctx, "ryo")) ? 1 : 0;
                                }))));
    }

    private static int list(CommandSourceStack source) {
        List<ShinobiRecords.Record> wanted = ShinobiRecords.get(source.getServer()).wanted();
        if (wanted.isEmpty()) {
            source.sendSuccess(() -> Component.translatable("message.shinobiarts.bounty_none").withStyle(ChatFormatting.GRAY), false);
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("message.shinobiarts.bounty_list_title").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        for (int i = 0; i < Math.min(10, wanted.size()); i++) {
            ShinobiRecords.Record r = wanted.get(i);
            int place = i + 1;
            source.sendSuccess(() -> Component.literal(place + ". ").withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(r.name).withStyle(ChatFormatting.WHITE))
                    .append(Component.literal("  " + PlayerDataManager.formatRyo(r.bounty) + " Ryo").withStyle(ChatFormatting.GOLD)), false);
        }
        return wanted.size();
    }
}

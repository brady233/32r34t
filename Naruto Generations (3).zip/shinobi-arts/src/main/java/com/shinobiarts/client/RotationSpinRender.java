package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxClient;
import com.shinobiarts.fx.Fx;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Quaternionf;

import java.util.HashSet;
import java.util.Set;

/**
 * Palm Rotation: the user spins on the spot inside the dome, fast at first and slowing as it ends (everyone sees it;
 * only the body turns, not the camera).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class RotationSpinRender {
    private static final Set<Integer> SPUN = new HashSet<>();

    private RotationSpinRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (FxClient.Active fx : FxClient.active()) {
            if (fx.type != Fx.Visual.PALM_ROTATION || fx.entityA != p.getId()) continue;
            float age = mc.level.getGameTime() - fx.start + event.getPartialTick();
            if (age < 0 || age > fx.ticks) continue;
            float t = age / fx.ticks;
            float turned = 360f * 5.5f * (t - 0.45f * t * t);       // about five turns, slowing toward the end
            PoseStack ps = event.getPoseStack();
            ps.pushPose();
            ps.mulPose(new Quaternionf().rotateY(-turned * (float) Math.PI / 180f));
            SPUN.add(p.getId());
            return;
        }
    }

    @SubscribeEvent
    public static void onRenderPost(RenderPlayerEvent.Post event) {
        if (SPUN.remove(event.getEntity().getId())) event.getPoseStack().popPose();
    }
}

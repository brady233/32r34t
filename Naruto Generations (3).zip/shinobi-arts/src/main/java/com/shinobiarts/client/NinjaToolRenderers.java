package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.entity.ExplosiveKunaiEntity;
import com.shinobiarts.entity.WireTrapEntity;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** Renderers for the ninja tools in the world: the explosive-tag kunai and the wire trap. */
public final class NinjaToolRenderers {
    private NinjaToolRenderers() {}

    /** A kunai flying or stuck tip-first, its explosive tag fluttering from the handle (and burning down once lit). */
    public static class ExplosiveKunai extends EntityRenderer<ExplosiveKunaiEntity> {
        private static final ResourceLocation TAG = new ResourceLocation(ShinobiArts.MODID, "textures/item/explosive_tag.png");
        private final ItemRenderer items;
        private ItemStack kunai = ItemStack.EMPTY;

        public ExplosiveKunai(EntityRendererProvider.Context context) {
            super(context);
            this.items = context.getItemRenderer();
        }

        @Override
        public void render(ExplosiveKunaiEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buffers, int light) {
            if (e.tickCount < 2 && this.entityRenderDispatcher.camera.getEntity().distanceToSqr(e) < 12.25) return;
            if (kunai.isEmpty()) kunai = new ItemStack(ModItems.KUNAI.get());
            ps.pushPose();
            ps.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partial, e.yRotO, e.getYRot()) - 90.0f));
            ps.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partial, e.xRotO, e.getXRot())));
            ps.pushPose();
            ps.mulPose(Axis.ZP.rotationDegrees(-45f));
            ps.translate(-0.1, -0.1, 0);
            ps.scale(0.55f, 0.55f, 0.55f);
            items.renderStatic(kunai, ItemDisplayContext.NONE, light, OverlayTexture.NO_OVERLAY, ps, buffers, e.level(), e.getId());
            ps.popPose();
            // the tag, hanging off the handle (+X points along the kunai, so the handle is toward -X)
            int fuse = e.getFuse();
            float burnt = fuse < 0 ? 0f : 1f - fuse / (float) ExplosiveKunaiEntity.FUSE_TICKS;
            float flap = Mth.sin((e.tickCount + partial) * 0.9f) * 0.12f;
            float len = 0.32f * (1f - 0.7f * burnt);
            Vec3 a = new Vec3(-0.32, 0.02, -0.06), b = new Vec3(-0.32, 0.02, 0.06);
            Vec3 c2 = b.add(-0.05, -len, flap), d = a.add(-0.05, -len, flap);
            VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TAG));
            FxDraw.Paint paper = new FxDraw.Paint(0, 0, 1, 1, 255, 255, 255, 255);
            FxDraw.vertex(vc, ps, a, paper, 0, 1f - (len / 0.32f), light, new Vec3(1, 0, 0));
            FxDraw.vertex(vc, ps, b, paper, 1, 1f - (len / 0.32f), light, new Vec3(1, 0, 0));
            FxDraw.vertex(vc, ps, c2, paper, 1, 1, light, new Vec3(1, 0, 0));
            FxDraw.vertex(vc, ps, d, paper, 0, 1, light, new Vec3(1, 0, 0));
            ps.popPose();
            super.render(e, yaw, partial, ps, buffers, light);
        }

        @Override
        public ResourceLocation getTextureLocation(ExplosiveKunaiEntity e) {
            return TextureAtlas.LOCATION_BLOCKS;
        }
    }

    /** A thin steel wire between its two ends, catching the light now and then, with a peg at each end. */
    public static class Wire extends EntityRenderer<WireTrapEntity> {
        public Wire(EntityRendererProvider.Context context) {
            super(context);
        }

        @Override
        public boolean shouldRender(WireTrapEntity e, Frustum frustum, double camX, double camY, double camZ) {
            Vec3 a = e.position(), b = a.add(e.span());
            return frustum.isVisible(new net.minecraft.world.phys.AABB(a, b).inflate(0.5))
                    && e.distanceToSqr(camX, camY, camZ) < 64 * 64;
        }

        @Override
        public void render(WireTrapEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buffers, int light) {
            Vec3 span = e.span();
            Vec3 cam = this.entityRenderDispatcher.camera.getPosition().subtract(e.getPosition(partial));
            Vec3 mid = span.scale(0.5);
            Vec3 side = span.cross(mid.subtract(cam));
            if (side.lengthSqr() < 1e-8) return;
            side = side.normalize().scale(0.014);
            VertexConsumer vc = FxDraw.lit(buffers);
            float glint = 0.5f + 0.5f * Mth.sin((e.tickCount + partial) * 0.05f + e.getId());
            int g = 150 + Math.round(60 * glint);
            FxDraw.Paint steel = new FxDraw.Paint(0.25f, 0.25f, 0.75f, 0.75f, g, g, Math.min(255, g + 10), 200);
            Vec3 sag = new Vec3(0, -0.04, 0);
            int n = 8;
            for (int i = 0; i < n; i++) {
                float s0 = i / (float) n, s1 = (i + 1) / (float) n;
                Vec3 p0 = span.scale(s0).add(sag.scale(4 * s0 * (1 - s0))), p1 = span.scale(s1).add(sag.scale(4 * s1 * (1 - s1)));
                FxDraw.quad(vc, ps, p0.add(side), p1.add(side), p1.subtract(side), p0.subtract(side), steel, light);
            }
            FxDraw.Paint peg = FxDraw.color(0x3A3A42, 1f);
            for (Vec3 end : new Vec3[]{Vec3.ZERO, span}) {
                FxDraw.box(vc, ps, end, new Vec3(0.04, 0, 0), new Vec3(0, 0.04, 0), new Vec3(0, 0, 0.04), peg, light);
            }
            super.render(e, yaw, partial, ps, buffers, light);
        }

        @Override
        public ResourceLocation getTextureLocation(WireTrapEntity e) {
            return TextureAtlas.LOCATION_BLOCKS;
        }
    }
}

package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * Screen effects from eye techniques that hit you or that you're using:
 * <ul>
 *   <li>Caught in Tsukuyomi: the world turns blood red and black, with a red moon hanging over it.</li>
 *   <li>Your Byakugan's All-Seeing Eye: a warning at the top of the screen when someone is right behind you.</li>
 * </ul>
 */
public final class EyeEffectsHud {
    private static final ResourceLocation MOON = new ResourceLocation(ShinobiArts.MODID, "textures/gui/eye_tsukuyomi.png");

    private EyeEffectsHud() {}

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    private static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) return;
        NinjaData d = ClientNinjaData.get();
        long now = player.level().getGameTime();
        if (d.isStunned(now) && d.getStunKind() == Afflictions.STUN_TSUKUYOMI) tsukuyomi(g, width, height);
        if (d.getAllSeeingUntil() > now && d.getActiveDojutsu() == Dojutsu.BYAKUGAN) behindWarning(g, mc, player, width);
    }

    private static void tsukuyomi(GuiGraphics g, int width, int height) {
        g.fill(0, 0, width, height, 0x88700008);
        int band = height / 4;
        g.fillGradient(0, 0, width, band, 0xE0000000, 0x00000000);
        g.fillGradient(0, height - band, width, height, 0x00000000, 0xE0000000);
        int size = Math.min(width, height) / 3;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.blit(MOON, (width - size) / 2, height / 12, size, size, 0, 0, 64, 64, 64, 64);
        RenderSystem.disableBlend();
    }

    /** Players and hostile creatures within 10 blocks, more than ~110 degrees off where you're looking. */
    private static void behindWarning(GuiGraphics g, Minecraft mc, LocalPlayer player, int width) {
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z).normalize();
        int count = 0;
        for (LivingEntity e : player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(10),
                cand -> cand != player && cand.isAlive() && (cand instanceof Player || cand instanceof Enemy))) {
            Vec3 to = e.position().subtract(player.position());
            Vec3 toFlat = new Vec3(to.x, 0, to.z);
            if (toFlat.lengthSqr() < 1e-4 || to.lengthSqr() > 100 || ByakuganVision.inBlindSpot(player, e)) continue;
            if (toFlat.normalize().dot(flat) < -0.35) count++;
        }
        if (count == 0) return;
        Component text = Component.translatable("hud.shinobiarts.behind_you", count);
        int w = mc.font.width(text);
        int x = (width - w) / 2, y = 24;
        g.fill(x - 6, y - 4, x + w + 6, y + 12, 0xA0200030);
        g.drawString(mc.font, text, x, y, (now(player) / 6) % 2 == 0 ? 0xFFFF5555 : 0xFFE0D0FF, true);
    }

    private static long now(LocalPlayer player) {
        return player.level().getGameTime();
    }
}

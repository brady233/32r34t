package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.JutsuProjectile;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Jutsu projectiles: the Great Fireball (textures/entity/jutsu/fireball.png, as big as its charge) and the Water
 * Bullet (water_ball.png) are glowing sprites that always face the camera, spinning slowly; the Water Dragon is a
 * whole dragon of water (WaterDragonRender). Every jutsu also keeps its particle trail; the others are drawn with
 * particles only.
 */
public class JutsuProjectileRenderer extends EntityRenderer<JutsuProjectile> {
    private static final ResourceLocation FIREBALL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/fireball.png");
    private static final ResourceLocation WATER_BALL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/water_ball.png");
    private static final ResourceLocation KAMUI_SHURIKEN = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/kamui_shuriken.png");

    public JutsuProjectileRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    protected int getBlockLightLevel(JutsuProjectile entity, BlockPos pos) {
        return 15;
    }

    @Override
    public void render(JutsuProjectile entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        ResourceLocation texture;
        float size, spin;
        switch (entity.getKind()) {
            case FIRE_BALL -> {
                texture = FIREBALL;
                size = 1.3f * entity.getScale();
                spin = 4f;
            }
            case WATER_BULLET -> {
                texture = WATER_BALL;
                size = 0.5f;
                spin = 12f;
            }
            case FIRE_SMALL -> {                                     // Phoenix Flower: a small fireball with a streaming tail
                texture = FIREBALL;
                size = 0.6f;
                spin = 10f;
                drawTrail(entity, partialTick, poseStack, buffer, 0xFF8A24, 0.42f);
            }
            case ICE_NEEDLE -> {                                     // a thin, glittering shard of ice
                drawShard(entity, partialTick, poseStack, buffer, false);
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            case BONE_BULLET -> {                                    // the bone of a fingertip, rounded knuckle first
                drawShard(entity, partialTick, poseStack, buffer, true);
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            case RASENSHURIKEN -> {                                  // the same ball and blades as in hand, flying
                poseStack.pushPose();
                poseStack.translate(0.0, entity.getBbHeight() / 2.0, 0.0);
                poseStack.mulPose(Axis.YP.rotationDegrees(-Mth.lerp(partialTick, entity.yRotO, entity.getYRot())));
                RasenganRender.drawBall(poseStack, buffer, RasenganRender.FULL_SIZE, com.shinobiarts.ninja.NinjaData.RASENGAN_FORM_TICKS + entity.tickCount + partialTick, true);
                poseStack.popPose();
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            case SUSANOO_ARROW -> {                                  // a long arrow of glowing chakra
                poseStack.pushPose();
                poseStack.translate(0.0, entity.getBbHeight() / 2.0, 0.0);
                net.minecraft.world.phys.Vec3 h = heading(entity);
                poseStack.mulPose(Axis.YP.rotationDegrees((float) Math.toDegrees(Math.atan2(h.x, h.z))));
                poseStack.mulPose(Axis.XP.rotationDegrees(-(float) Math.toDegrees(Math.asin(Mth.clamp(h.y, -1, 1)))));
                float s = entity.getScale();
                poseStack.scale(s, s, s);
                PoseStack.Pose pose = poseStack.last();
                VertexConsumer vc = buffer.getBuffer(RenderType.eyes(ARROW_WHITE));
                int c = entity.getColor();
                float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
                for (int pass = 0; pass < 2; pass++) {
                    float w = pass == 0 ? 0.22f : 0.07f, k = pass == 0 ? 0.55f : 1f;
                    float cr = pass == 0 ? r * k : Math.min(1, 0.6f + r * 0.4f), cg = pass == 0 ? g * k : Math.min(1, 0.6f + g * 0.4f),
                            cb = pass == 0 ? b * k : Math.min(1, 0.6f + b * 0.4f);
                    for (int plane = 0; plane < 2; plane++) {          // crossed: it looks solid from every side
                        float px = plane == 0 ? w : 0, py = plane == 0 ? 0 : w;
                        arrowQuad(vc, pose, -px, -py, -2.2f, px, py, -2.2f, px, py, 0.9f, -px, -py, 0.9f, cr, cg, cb);          // shaft
                        float hx = plane == 0 ? w * 3.2f : 0, hy = plane == 0 ? 0 : w * 3.2f;
                        arrowQuad(vc, pose, -hx, -hy, 0.75f, hx, hy, 0.75f, 0, 0, 1.6f, 0, 0, 1.6f, cr, cg, cb);               // head
                        float fx = plane == 0 ? w * 2.2f : 0, fy = plane == 0 ? 0 : w * 2.2f;
                        arrowQuad(vc, pose, -fx, -fy, -2.4f, fx, fy, -2.4f, px, py, -1.7f, -px, -py, -1.7f, cr, cg, cb);       // fletching
                    }
                }
                poseStack.popPose();
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            case KAMUI_SHURIKEN -> {                                 // a huge black shuriken spinning flat as it flies
                poseStack.pushPose();
                poseStack.translate(0.0, entity.getBbHeight() / 2.0, 0.0);
                net.minecraft.world.phys.Vec3 h = heading(entity);
                poseStack.mulPose(Axis.YP.rotationDegrees((float) Math.toDegrees(Math.atan2(h.x, h.z))));
                poseStack.mulPose(Axis.XP.rotationDegrees(90f - (float) Math.toDegrees(Math.asin(Mth.clamp(h.y, -1, 1))) * 0.5f + 8f));
                poseStack.mulPose(Axis.ZP.rotationDegrees(-(entity.tickCount + partialTick) * 38f));
                float s = entity.getScale();
                poseStack.scale(s, s, s);
                PoseStack.Pose pose = poseStack.last();
                VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(KAMUI_SHURIKEN));
                kamuiVertex(vc, pose, -0.5f, -0.5f, 0f, 1f, packedLight);
                kamuiVertex(vc, pose, 0.5f, -0.5f, 1f, 1f, packedLight);
                kamuiVertex(vc, pose, 0.5f, 0.5f, 1f, 0f, packedLight);
                kamuiVertex(vc, pose, -0.5f, 0.5f, 0f, 0f, packedLight);
                poseStack.popPose();
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            case WATER_SHARK -> {
                WaterSharkRender.render(entity, partialTick, poseStack, buffer, packedLight);
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            case WATER_DRAGON -> {
                WaterDragonRender.render(entity, partialTick, poseStack, buffer, packedLight);
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            default -> {
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
        }
        poseStack.pushPose();
        poseStack.translate(0.0, entity.getBbHeight() / 2.0, 0.0);
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180f));
        poseStack.mulPose(Axis.ZP.rotationDegrees((entity.tickCount + partialTick) * spin));
        poseStack.scale(size, size, size);
        PoseStack.Pose pose = poseStack.last();
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucentEmissive(texture));
        vertex(consumer, pose.pose(), pose.normal(), -0.5f, -0.5f, 0f, 1f);
        vertex(consumer, pose.pose(), pose.normal(), 0.5f, -0.5f, 1f, 1f);
        vertex(consumer, pose.pose(), pose.normal(), 0.5f, 0.5f, 1f, 0f);
        vertex(consumer, pose.pose(), pose.normal(), -0.5f, 0.5f, 0f, 0f);
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
    }

    private static final ResourceLocation ARROW_WHITE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/white.png");

    private static void arrowQuad(VertexConsumer vc, PoseStack.Pose pose, float x0, float y0, float z0, float x1, float y1, float z1,
                                  float x2, float y2, float z2, float x3, float y3, float z3, float r, float g, float b) {
        float[][] pts = {{x0, y0, z0}, {x1, y1, z1}, {x2, y2, z2}, {x3, y3, z3}};
        for (int pass = 0; pass < 2; pass++) {                       // both sides
            for (int i = 0; i < 4; i++) {
                float[] q = pts[pass == 0 ? i : 3 - i];
                vc.vertex(pose.pose(), q[0], q[1], q[2]).color(r, g, b, 1f).uv(0.5f, 0.5f).overlayCoords(OverlayTexture.NO_OVERLAY)
                        .uv2(0xF000F0).normal(pose.normal(), 0f, 1f, 0f).endVertex();
            }
        }
    }

    private static void kamuiVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float u, float v, int light) {
        vc.vertex(pose.pose(), x, y, 0f).color(255, 255, 255, 255).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(pose.normal(), 0f, 1f, 0f).endVertex();
    }

    /** The way it's flying (or facing, if it's still). */
    private static net.minecraft.world.phys.Vec3 heading(JutsuProjectile e) {
        net.minecraft.world.phys.Vec3 v = e.getDeltaMovement();
        return v.lengthSqr() > 1e-6 ? v.normalize() : net.minecraft.world.phys.Vec3.directionFromRotation(e.getXRot(), e.getYRot());
    }

    /** A glowing tail streaming behind (Phoenix Flower's flames). */
    private void drawTrail(JutsuProjectile e, float partial, PoseStack ps, MultiBufferSource buffers, int rgb, float width) {
        net.minecraft.world.phys.Vec3 back = heading(e).scale(-1);
        net.minecraft.world.phys.Vec3 mid = new net.minecraft.world.phys.Vec3(0, e.getBbHeight() / 2.0, 0);
        java.util.List<net.minecraft.world.phys.Vec3> pts = new java.util.ArrayList<>();
        for (int i = 0; i <= 6; i++) pts.add(mid.add(back.scale(i * 0.28)).add(0, Math.sin((e.tickCount + partial) * 0.8 + i) * 0.04 * i, 0));
        org.joml.Vector3f camL = new org.joml.Matrix4f(ps.last().pose()).invert().transformPosition(new org.joml.Vector3f());
        net.minecraft.world.phys.Vec3 cam = new net.minecraft.world.phys.Vec3(camL.x(), camL.y(), camL.z());
        VertexConsumer add = com.shinobiarts.client.fx.FxDraw.additive(buffers);
        com.shinobiarts.client.fx.FxDraw.ribbon(add, ps, cam, pts, width, 0.95f, com.shinobiarts.client.fx.FxDraw.addColor(rgb, 0.9f),
                com.shinobiarts.client.fx.FxDraw.addColor(0x802008, 0f), LightTexture.FULL_BRIGHT);
    }

    /** An ice needle (a long thin crystal) or a finger bone (a short shaft with a rounded knuckle), along its flight. */
    private void drawShard(JutsuProjectile e, float partial, PoseStack ps, MultiBufferSource buffers, boolean bone) {
        net.minecraft.world.phys.Vec3 dir = heading(e);
        net.minecraft.world.phys.Vec3 mid = new net.minecraft.world.phys.Vec3(0, e.getBbHeight() / 2.0, 0);
        int light = LightTexture.FULL_BRIGHT;
        if (bone) {
            VertexConsumer vc = com.shinobiarts.client.fx.FxDraw.blocks(buffers);
            com.shinobiarts.client.fx.FxDraw.Paint p = com.shinobiarts.client.fx.FxDraw.block("minecraft:block/bone_block_side", 0xFFFFFF, 1f);
            net.minecraft.world.phys.Vec3 tail = mid.subtract(dir.scale(0.22)), tip = mid.add(dir.scale(0.16));
            com.shinobiarts.client.fx.FxDraw.tube(vc, ps, java.util.List.of(tail, mid, tip), new float[]{0.06f, 0.05f, 0.07f}, 6, p, 1f, light, true);
            com.shinobiarts.client.fx.FxDraw.cone(vc, ps, tip, tip.add(dir.scale(0.12)), 0.07f, 6, p, light);
        } else {
            VertexConsumer vc = com.shinobiarts.client.fx.FxDraw.glow(buffers);
            com.shinobiarts.client.fx.FxDraw.crystal(vc, ps, mid, dir, 0.85f, 0.05f, 4, com.shinobiarts.client.fx.FxDraw.color(0xE4F6FF, 0.9f), light);
            drawTrail(e, partial, ps, buffers, 0x9FD8FF, 0.07f);
        }
    }

    private static void vertex(VertexConsumer consumer, Matrix4f pose, Matrix3f normal, float x, float y, float u, float v) {
        consumer.vertex(pose, x, y, 0f).color(255, 255, 255, 255).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(normal, 0f, 1f, 0f).endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(JutsuProjectile entity) {
        return FIREBALL;
    }
}

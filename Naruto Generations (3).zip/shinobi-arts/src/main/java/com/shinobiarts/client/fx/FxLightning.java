package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Lightning Release: Chidori (a screeching ball of lightning in the hand, arcs lashing out of it and one dragging along
 * the ground), lightning bolts (the Chidori's path), and Thunder Strike (a huge forked bolt from the sky).
 */
final class FxLightning {
    static final int BLUE = 0x8CC8FF;

    private FxLightning() {}

    /** Where a player's lead hand is (with the arm held out a little), in world space. */
    static Vec3 hand(Entity e, float partial, boolean right) {
        float yaw = Mth.rotLerp(partial, e instanceof net.minecraft.world.entity.LivingEntity l ? l.yBodyRotO : e.yRotO,
                e instanceof net.minecraft.world.entity.LivingEntity l2 ? l2.yBodyRot : e.getYRot()) * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw)), rightV = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
        return e.getPosition(partial).add(0, e.getBbHeight() * 0.48, 0).add(fwd.scale(0.5)).add(rightV.scale(right ? 0.38 : -0.38));
    }

    /** The Chidori in the caster's hand: a white-hot core, a blue glow and arcs crackling out of it. */
    static void chidori(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        float age = c.age();
        float fade = 1f - Mth.clamp((age - (c.fx().ticks - 4)) / 4f, 0f, 1f);
        Vec3 h = hand(e, c.partial(), true);
        long tick = (long) age;
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.billboard(add, c.ps(), c.camera(), h, 1.3f, 1.3f, 0, FxDraw.addColor(BLUE, 0.35f * fade), FxDraw.FULL);
        FxDraw.billboard(add, c.ps(), c.camera(), h, 0.45f, 0.45f, 0, FxDraw.addColor(0xFFFFFF, 0.95f * fade), FxDraw.FULL);
        RandomSource r = FxDraw.rng(c.fx().seed, (int) tick);
        for (int k = 0; k < 11; k++) {
            Vec3 d = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).normalize().scale(0.5 + r.nextDouble() * 0.7);
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), h, h.add(d), c.fx().seed * 31 + tick * 7 + k, 0.12f, 0.035f, BLUE, fade, 1);
        }
        // the arc it drags along the ground behind
        Vec3 ground = new Vec3(h.x, e.getPosition(c.partial()).y + 0.05, h.z).subtract(e.getLookAngle().multiply(1, 0, 1).scale(0.8));
        FxDraw.bolt(c.buffers(), c.ps(), c.cam(), h, ground, c.fx().seed + tick * 13, 0.18f, 0.04f, BLUE, fade * 0.9f, 2);
    }

    /** A lightning bolt between two points, flickering. */
    static void bolt(FxClient.Ctx c) {
        float age = c.age();
        float fade = 1f - FxDraw.smooth(age / c.fx().ticks);
        long flicker = (long) (age / 2);
        float len = (float) c.fx().a.distanceTo(c.fx().b);
        FxDraw.bolt(c.buffers(), c.ps(), c.cam(), c.fx().a, c.fx().b, c.fx().seed + flicker * 101, Math.min(1.2f, 0.12f * len),
                0.06f * c.fx().size, BLUE, fade, 3);
    }

    /** Thunder Strike: a huge forked bolt from the sky, a blinding flash and a ring of light where it lands. */
    static void thunder(FxClient.Ctx c) {
        Vec3 p = c.fx().a;
        float age = c.age();
        float fade = 1f - FxDraw.smooth(age / c.fx().ticks);
        boolean on = age < 3 || ((int) age % 3) != 2;                 // it flickers
        RandomSource r = FxDraw.rng(c.fx().seed, 0);
        Vec3 sky = p.add(r.nextGaussian() * 4, 42, r.nextGaussian() * 4);
        if (on) {
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), sky, p, c.fx().seed + (long) (age / 3) * 17, 3.2f, 0.32f, 0xB4DCFF, fade, 9);
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), sky.add(2, 0, -1), p, c.fx().seed * 7 + (long) (age / 3) * 19, 3.5f, 0.14f, 0xB4DCFF, fade * 0.6f, 4);
        }
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.billboard(add, c.ps(), c.camera(), p.add(0, 1, 0), 6f * (1 - age / c.fx().ticks * 0.5f), 6f, 0,
                FxDraw.addColor(0xDDEEFF, 0.55f * fade), FxDraw.FULL);
        float ring = 1f + age * 0.55f;
        FxDraw.ring(add, c.ps(), p.add(0, 0.08, 0), new Vec3(0, 1, 0), ring, 0.6f, 40, FxDraw.addColor(0xBFE2FF, 0.8f * fade),
                FxDraw.addColor(0x5FA8FF, 0f), FxDraw.FULL);
    }
}

package com.shinobiarts.fx;

import net.minecraft.world.phys.Vec3;

/**
 * Chibaku Tensei's timeline, shared by the server (who gets pulled in, when it lands) and the client (where the ball is
 * drawn): the black core rises slowly from just above where it was thrown up to {@link #RISE_HEIGHT} blocks higher,
 * gathering rock into a growing sphere; it hangs there a moment once it's done; then the whole ball falls and crashes
 * into the ground.
 *
 * @param start  where the core first appears
 * @param groundY the ground under it (where it lands)
 */
public record ChibakuPath(Vec3 start, double groundY) {
    public static final int RISE = 240;          // 12 s of rising and gathering
    public static final int HANG = 30;
    public static final double RISE_HEIGHT = 26.0;
    public static final float FINAL_RADIUS = 5.5f;
    public static final double GRAVITY = 0.06;
    public static final int CRASH = 40;          // the ball breaking apart after it lands

    private static double smooth(double t) {
        t = Math.max(0, Math.min(1, t));
        return t * t * (3 - 2 * t);
    }

    public double top() {
        return start.y + RISE_HEIGHT;
    }

    /** Ticks the fall takes from the top to the ground. */
    public int fallTicks() {
        double h = Math.max(1, top() - (groundY + FINAL_RADIUS * 0.7));
        return (int) Math.ceil(Math.sqrt(2 * h / GRAVITY));
    }

    /** The tick it hits the ground. */
    public int landTick() {
        return RISE + HANG + fallTicks();
    }

    public int totalTicks() {
        return landTick() + CRASH;
    }

    /** The ball's radius: it grows as rock packs onto it, to {@link #FINAL_RADIUS}. */
    public float radius(float t) {
        return (float) (0.6 + (FINAL_RADIUS - 0.6) * smooth(t / (RISE * 0.9)));
    }

    /** Where the core is at tick {@code t}. */
    public Vec3 core(float t) {
        double y;
        if (t < RISE) y = start.y + RISE_HEIGHT * smooth(t / RISE);
        else if (t < RISE + HANG) y = top();
        else {
            double f = Math.min(t, landTick()) - (RISE + HANG);
            y = Math.max(groundY + FINAL_RADIUS * 0.7, top() - 0.5 * GRAVITY * f * f);
        }
        return new Vec3(start.x, y, start.z);
    }

    public boolean falling(float t) {
        return t >= RISE + HANG && t < landTick();
    }

    public boolean landed(float t) {
        return t >= landTick();
    }
}

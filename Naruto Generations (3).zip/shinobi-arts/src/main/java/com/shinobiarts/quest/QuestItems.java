package com.shinobiarts.quest;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Matching, counting and taking the items a gather quest asks for (an item id, or "#ns:tag"). */
public final class QuestItems {
    private QuestItems() {}

    public static boolean matches(String target, ItemStack stack) {
        if (stack.isEmpty() || target == null || target.isEmpty()) return false;
        if (target.startsWith("#")) {
            ResourceLocation id = ResourceLocation.tryParse(target.substring(1));
            return id != null && stack.is(TagKey.create(Registries.ITEM, id));
        }
        ResourceLocation id = ResourceLocation.tryParse(target);
        return id != null && stack.is(BuiltInRegistries.ITEM.get(id)) && !stack.hasTag();
    }

    public static int count(Inventory inventory, String target) {
        int n = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (matches(target, s)) n += s.getCount();
        }
        return n;
    }

    /** Copies of the exact stacks {@link #take} would remove, without changing the inventory. */
    public static java.util.List<ItemStack> peek(Inventory inventory, String target, int amount) {
        java.util.List<ItemStack> out = new java.util.ArrayList<>();
        for (int i = 0; i < inventory.getContainerSize() && amount > 0; i++) {
            ItemStack s = inventory.getItem(i);
            if (!matches(target, s)) continue;
            int n = Math.min(amount, s.getCount());
            ItemStack copy = s.copy();
            copy.setCount(n);
            out.add(copy);
            amount -= n;
        }
        return out;
    }

    /** Takes exactly {@code amount} matching items (call only after checking the count). Returns what was taken. */
    public static java.util.List<ItemStack> take(Inventory inventory, String target, int amount) {
        java.util.List<ItemStack> taken = new java.util.ArrayList<>();
        for (int i = 0; i < inventory.getContainerSize() && amount > 0; i++) {
            ItemStack s = inventory.getItem(i);
            if (!matches(target, s)) continue;
            int n = Math.min(amount, s.getCount());
            taken.add(s.split(n));
            amount -= n;
        }
        inventory.setChanged();
        return taken;
    }

    /** The item shown for a target (any log shows as an oak log). */
    public static Item icon(String target) {
        if (target.startsWith("#")) return target.endsWith("logs") ? Items.OAK_LOG : Items.CHEST;
        ResourceLocation id = ResourceLocation.tryParse(target);
        return id == null ? Items.BARRIER : BuiltInRegistries.ITEM.get(id);
    }
}

package com.shinobiarts.quest;

import com.shinobiarts.Config;
import net.minecraftforge.common.ForgeConfigSpec;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.IsoFields;
import java.time.temporal.TemporalAdjusters;

/** How often a set of random quests is rerolled (server clock): every hour, day, week (Monday) and month. */
public enum QuestPeriod {
    HOURLY("hourly", Config.HOURLY_QUESTS),
    DAILY("daily", Config.DAILY_QUESTS),
    WEEKLY("weekly", Config.WEEKLY_QUESTS),
    MONTHLY("monthly", Config.MONTHLY_QUESTS);

    private final String id;
    private final ForgeConfigSpec.IntValue count;

    QuestPeriod(String id, ForgeConfigSpec.IntValue count) {
        this.id = id;
        this.count = count;
    }

    public String id() {
        return id;
    }

    /** How many quests of this kind each player is offered. */
    public int count() {
        return Config.i(count);
    }

    /** Identifies the current hour/day/week/month; when it changes, the quests are rerolled. */
    public String key(LocalDateTime now) {
        return switch (this) {
            case HOURLY -> now.toLocalDate() + "T" + now.getHour();
            case DAILY -> now.toLocalDate().toString();
            case WEEKLY -> now.get(IsoFields.WEEK_BASED_YEAR) + "-W" + now.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
            case MONTHLY -> now.getYear() + "-" + now.getMonthValue();
        };
    }

    /** Seconds until the next reroll. */
    public long secondsUntilReset(LocalDateTime now) {
        LocalDateTime next = switch (this) {
            case HOURLY -> now.withMinute(0).withSecond(0).withNano(0).plusHours(1);
            case DAILY -> now.toLocalDate().plusDays(1).atStartOfDay();
            case WEEKLY -> now.toLocalDate().with(TemporalAdjusters.next(DayOfWeek.MONDAY)).atStartOfDay();
            case MONTHLY -> now.toLocalDate().with(TemporalAdjusters.firstDayOfNextMonth()).atStartOfDay();
        };
        return Math.max(0, Duration.between(now, next).getSeconds());
    }
}

"""
Draws the clan release emblems in the same octagon style as the nature releases: the release's kanji on a coloured
octagon with a black rim (lighter in the middle, darker toward the rim).

  Wood 木 (Senju), Ice 氷 (Yuki), Magnet 磁 (Kazekage), Bone 骨 (Kaguya), Sealing 封 (Uzumaki),
  and the advanced natures: Lava 溶, Storm 嵐, Boil 沸, Scorch 灼

Writes textures/nature/<id>.png (64x64, HUD and menus) and textures/item/release_<id>.png (32x32, the held item).
Needs the Noto Serif CJK font (fonts-noto-cjk). Run: python3 tools/make_clan_releases.py
"""
import math
import os

from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures")
SERIF = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"

# release id: (kanji, fill colour)
RELEASES = {
    "wood": ("木", (112, 168, 60)),
    "ice": ("氷", (150, 222, 246)),
    "magnet": ("磁", (128, 132, 150)),
    "bone": ("骨", (232, 224, 198)),
    "sealing": ("封", (204, 60, 92)),
    "medical": ("医", (96, 214, 140)),   # Medical Release (everyone's, not a clan's)
    # the advanced natures (two elements at once; awakened, not born into a clan)
    "lava": ("溶", (232, 84, 28)),
    "storm": ("嵐", (138, 212, 255)),
    "boil": ("沸", (216, 228, 234)),
    "scorch": ("灼", (255, 160, 64)),
}


def octagon(c, r):
    return [(c + r * math.cos(math.radians(22.5 + 45 * k)), c + r * math.sin(math.radians(22.5 + 45 * k))) for k in range(8)]


def emblem(kanji, color, size=64):
    S = 512
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = S / 2
    d.polygon(octagon(c, S * 0.5), fill=(0, 0, 0, 255))  # the black rim
    for k in range(40, 0, -1):  # fill: lighter in the middle, darker toward the rim
        t = k / 40
        shade = 0.62 + 0.38 * (1 - t) ** 0.8
        col = tuple(min(255, int(v * shade + (255 - v) * 0.12 * (1 - t))) for v in color) + (255,)
        d.polygon(octagon(c, S * 0.445 * t), fill=col)
    f = ImageFont.truetype(SERIF, int(S * 0.56), index=0)
    box = d.textbbox((0, 0), kanji, font=f)
    w, h = box[2] - box[0], box[3] - box[1]
    pos = (c - w / 2 - box[0], c - h / 2 - box[1])
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).text((pos[0] + 6, pos[1] + 8), kanji, font=f, fill=(0, 0, 0, 90))
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(6)))
    d.text(pos, kanji, font=f, fill=(10, 8, 8, 255))
    return img.resize((size, size), Image.LANCZOS)


def main():
    os.makedirs(os.path.join(TEX, "nature"), exist_ok=True)
    os.makedirs(os.path.join(TEX, "item"), exist_ok=True)
    for rid, (kanji, color) in RELEASES.items():
        big = emblem(kanji, color, 64)
        big.save(os.path.join(TEX, "nature", rid + ".png"))
        big.resize((32, 32), Image.LANCZOS).save(os.path.join(TEX, "item", "release_" + rid + ".png"))
    print("drew", len(RELEASES), "clan release emblems")


if __name__ == "__main__":
    main()

"""The Rinnegan release's emblem: the ripple-patterned eye (purple iris, black rings, a small pupil) on a dark
octagon like the other releases. If tools/source_art/rinnegan.png exists it is used instead (fitted to 64x64)."""
import os
from PIL import Image, ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures")
SRC = os.path.join(HERE, "source_art", "rinnegan.png")

def draw(size=64):
    S = size * 4
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = S / 2
    r = S * 0.47
    d.ellipse([c - r, c - r, c + r, c + r], fill=(40, 22, 60, 255), outline=(20, 10, 30, 255), width=int(S * 0.03))
    r = S * 0.42
    d.ellipse([c - r, c - r, c + r, c + r], fill=(178, 150, 222, 255))
    for k, frac in enumerate([0.34, 0.25, 0.16]):            # the ripples
        rr = S * frac
        d.ellipse([c - rr, c - rr, c + rr, c + rr], outline=(36, 18, 52, 255), width=int(S * 0.028))
    rr = S * 0.065
    d.ellipse([c - rr, c - rr, c + rr, c + rr], fill=(30, 14, 44, 255))
    hi = S * 0.05                                            # a glint
    d.ellipse([c - S * 0.2 - hi, c - S * 0.22 - hi, c - S * 0.2 + hi, c - S * 0.22 + hi], fill=(255, 255, 255, 180))
    return im.resize((size, size), Image.LANCZOS)

if os.path.exists(SRC):
    big = Image.open(SRC).convert("RGBA")
    big.thumbnail((64, 64), Image.LANCZOS)
    canvas = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    canvas.alpha_composite(big, ((64 - big.width) // 2, (64 - big.height) // 2))
    big = canvas
else:
    big = draw()
big.save(os.path.join(TEX, "nature", "rinnegan.png"))
if os.path.exists(SRC):
    # the 32x32 item: the picture's own colours (its purple-to-grey gradient), redrawn with fewer, crisper rings so it
    # still reads as the Rinnegan that small
    src = Image.open(SRC).convert("RGBA")
    top = src.getpixel((src.width // 2, int(src.height * 0.12)))
    bot = src.getpixel((src.width // 2, int(src.height * 0.9)))
    small = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    for y in range(32):
        for x in range(32):
            dx, dy = x + 0.5 - 16, y + 0.5 - 16
            r = (dx * dx + dy * dy) ** 0.5
            if r > 15.2:
                continue
            t = y / 31
            col = tuple(round(top[i] * (1 - t) + bot[i] * t) for i in range(3))
            ring = r < 1.6 or any(abs(r - rr) < 0.55 for rr in (4.0, 7.0, 10.0, 13.0))
            small.putpixel((x, y), (16, 12, 20, 255) if ring else col + (255,))
small.save(os.path.join(TEX, "item", "release_rinnegan.png"))
print("ok")

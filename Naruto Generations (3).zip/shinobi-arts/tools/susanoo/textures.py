"""
One small tiling texture per material instead of a packed cube atlas: a greyscale detail map (tinted in game with the
player's chosen colour, alpha = how see-through) and a glow map (drawn full-bright in the chakra colour on top).
u runs along each part (bones, ribs, feathers, blades), v runs around it, so grain follows the shapes.
All maps tile seamlessly (periodic noise), 128 x 128, smooth-filtered in game (a .mcmeta with "blur": true).
"""
import os

import numpy as np
from PIL import Image

N = 128
RNG = np.random.default_rng(11)

# which colour slot tints each material, and its base opacity (the glow and rim light add to it)
MATERIALS = {
    "bone":       {"slot": "body",   "opacity": 0.60, "tex": "bone"},
    "bone_inner": {"slot": "body",   "opacity": 0.26, "tex": "bone"},
    "muscle":     {"slot": "body",   "opacity": 0.50, "tex": "muscle"},
    "flame":      {"slot": "body",   "opacity": 0.40, "tex": "flame"},
    "shadow":     {"slot": "body",   "opacity": 0.80, "tex": "shadow"},
    "armor":      {"slot": "armor",  "opacity": 0.66, "tex": "armor"},
    "trim":       {"slot": "armor",  "opacity": 0.78, "tex": "trim"},
    "wing":       {"slot": "armor",  "opacity": 0.48, "tex": "wing"},
    "weapon":     {"slot": "weapon", "opacity": 0.80, "tex": "weapon"},
    "eye":        {"slot": "eyes",   "opacity": 1.00, "tex": "eye"},
    "gem":        {"slot": "chakra", "opacity": 0.62, "tex": "gem"},
}


def noise(scale_x, scale_y, octaves=3, seed=None):
    """Seamless value noise in 0..1: random spectrum, low-passed (periodic by construction)."""
    rng = np.random.default_rng(seed) if seed is not None else RNG
    out = np.zeros((N, N))
    amp = 1.0
    for o in range(octaves):
        f = np.fft.fft2(rng.normal(size=(N, N)))
        fy = np.fft.fftfreq(N)[:, None] * N
        fx = np.fft.fftfreq(N)[None, :] * N
        cut = np.exp(-((fx / (scale_x * 2 ** o)) ** 2 + (fy / (scale_y * 2 ** o)) ** 2))
        layer = np.real(np.fft.ifft2(f * cut))
        layer = (layer - layer.mean()) / (layer.std() + 1e-9)
        out += layer * amp
        amp *= 0.5
    out = (out - out.min()) / (out.max() - out.min())
    return out


Y, X = np.mgrid[0:N, 0:N]
U, Vv = X / N, Y / N          # u along the part (texture x), v around it (texture y)


def save(name, grey, alpha, glow, out):
    grey = np.clip(grey, 0, 255).astype(np.uint8)
    alpha = np.clip(alpha, 0, 255).astype(np.uint8)
    glow = np.clip(glow, 0, 255).astype(np.uint8)
    Image.fromarray(np.dstack([grey, grey, grey, alpha]), "RGBA").save(os.path.join(out, name + ".png"))
    Image.fromarray(glow, "L").convert("RGB").save(os.path.join(out, name + "_glow.png"))


def make(out):
    os.makedirs(out, exist_ok=True)
    full = np.full((N, N), 255.0)

    # bone: chalky with pores and hairline cracks running along the bone
    n = noise(10, 10)
    pores = noise(40, 40, 1, seed=3) > 0.86
    cracks = np.abs(noise(3, 26, 2, seed=4) - 0.5) < 0.012
    g = 222 + (n - 0.5) * 34 - pores * 30 - cracks * 45
    glow = cracks * 70 + (noise(4, 4, 1, seed=5) > 0.8) * 25
    save("bone", g, full * 0.95, glow, out)

    # muscle: fibres running along each muscle, with glowing chakra veins
    fib = np.sin(2 * np.pi * (Vv * 18 + noise(2, 6, 2, seed=6) * 1.6))
    g = 205 + fib * 16 + (noise(8, 8, seed=7) - 0.5) * 20
    vein = np.abs(noise(2.5, 4, 2, seed=8) - 0.5) < 0.008
    save("muscle", g, full * (0.9 + 0.1 * fib), vein * 200 + (fib > 0.85) * 30, out)

    # flame: streaks licking along the flame, bright cores
    st = noise(1.6, 14, 3, seed=9)
    g = 160 + st * 95
    save("flame", g, 120 + st * 135, np.clip((st - 0.35) * 380, 0, 255), out)

    # shadow (eye sockets, mouths): nearly black
    save("shadow", 40 + noise(6, 6, seed=10) * 20, full * 0.9, np.zeros((N, N)), out)

    # armour: brushed metal, plate seams across every quarter tile, a double engraved line and rivets
    br = noise(1.2, 30, 2, seed=12)
    g = 172 + (br - 0.5) * 30
    seam = (X % 64 < 2)
    g[seam] = 110
    g[(X % 64 == 2)] = 220
    eng = (np.abs(Y - 30) < 1) | (np.abs(Y - 34) < 1) | (np.abs(Y - 94) < 1) | (np.abs(Y - 98) < 1)
    g[eng] -= 55
    rv = ((X % 64 - 10) ** 2 + (Y % 64 - 16) ** 2 < 7) | ((X % 64 - 54) ** 2 + (Y % 64 - 16) ** 2 < 7)
    g[rv] = 245
    glow = eng * 140 + seam * 60 + rv * 90
    save("armor", g, full, glow, out)

    # trim: bright, polished, with a running diamond pattern
    dia = (np.abs((X % 32) - 16) + np.abs((Y % 32) - 16)) % 16
    g = 225 + (noise(6, 6, seed=13) - 0.5) * 16 - (dia < 1.5) * 50
    save("trim", g, full, (dia < 1.5) * 150 + 30, out)

    # wing feathers: a bright shaft down the middle of each face, barbs angled out from it
    d = np.minimum(np.abs(Vv - 0.25), np.abs(Vv - 0.75))
    barbs = np.sin(2 * np.pi * (U * 10 + d * 16 + noise(2, 8, 1, seed=14) * 0.4))
    g = 185 + barbs * 20
    shaft = d < 0.018
    g[shaft] = 250
    save("wing", g, 200 + barbs * 40, shaft * 230 + (barbs > 0.8) * 60, out)

    # weapon: polished blade, a wavy temper line (hamon) and a glowing cutting edge (v = 0 / 1 is the edge)
    e = np.minimum(Vv, 1 - Vv)
    hamon = np.abs(e - (0.12 + 0.035 * np.sin(2 * np.pi * U * 6) + 0.015 * np.sin(2 * np.pi * U * 17))) < 0.012
    g = 236 + (noise(1.5, 20, 2, seed=15) - 0.5) * 18 - hamon * 30
    save("weapon", g, full, np.clip((0.14 - e) * 1800, 0, 255) + hamon * 160 + 60, out)

    # eyes and the gem: plain white, glowing
    save("eye", full, full, full, out)
    save("gem", 230 + noise(8, 8, seed=16) * 25, full, 120 + noise(3, 3, seed=17) * 135, out)


if __name__ == "__main__":
    make(os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", "textures"))

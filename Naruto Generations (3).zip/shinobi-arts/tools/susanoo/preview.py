"""A tiny software renderer for checking Susanoo meshes without the game: z-buffered, flat-shaded, one colour per
material, optional bone pose (degrees per bone, applied like SusanooPose). Used by the tools only.

    from preview import render
    render(mesh_export_dict, "out.png", view=(yaw, pitch), pose={...}, focus=(x, y, z), radius=40, size=700)
"""
import math

import numpy as np
from PIL import Image

COLORS = {"bone": (220, 210, 235), "bone_inner": (170, 160, 190), "muscle": (150, 110, 230), "flame": (190, 140, 255),
          "shadow": (35, 25, 45), "armor": (110, 80, 210), "trim": (230, 200, 120), "wing": (140, 120, 240),
          "weapon": (240, 240, 255), "eye": (255, 255, 255), "gem": (255, 120, 120)}


def rot(rx, ry, rz):
    x, y, z = map(math.radians, (rx, ry, rz))
    Rx = np.array([[1, 0, 0], [0, math.cos(x), -math.sin(x)], [0, math.sin(x), math.cos(x)]])
    Ry = np.array([[math.cos(y), 0, math.sin(y)], [0, 1, 0], [-math.sin(y), 0, math.cos(y)]])
    Rz = np.array([[math.cos(z), -math.sin(z), 0], [math.sin(z), math.cos(z), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def bone_mats(bones, pose):
    out = {}
    for b in bones:
        r = pose.get(b["name"], (0, 0, 0))
        piv = np.array(b["pivot"])
        M = np.eye(4)
        M[:3, :3] = rot(*r)
        T = np.eye(4); T[:3, 3] = piv
        Ti = np.eye(4); Ti[:3, 3] = -piv
        local = T @ M @ Ti
        out[b["name"]] = (out[b["parent"]] if b["parent"] else np.eye(4)) @ local
    return out


def render(data, path, view=(30, 15), pose=None, focus=None, radius=None, size=700, extra=(), colors=None, bg=30.0, want_mask=False):
    pose = pose or {}
    mats = bone_mats(data["bones"], pose)
    names = [b["name"] for b in data["bones"]]
    tris, cols = [], []
    for p in list(data["pieces"]) + list(extra):
        bone = p["bone"] if isinstance(p["bone"], str) else names[p["bone"]]
        V = np.asarray(p["pos"]).reshape(-1, 3)
        V = (mats[bone] @ np.c_[V, np.ones(len(V))].T).T[:, :3]
        F = np.asarray(p["idx"]).reshape(-1, 3)
        tris.append(V[F])
        pal = colors or COLORS
        cols.append(np.repeat([pal.get(p["mat"], (200, 200, 200))], len(F), axis=0))
    T = np.concatenate(tris)
    C = np.concatenate(cols).astype(float)
    yaw, pitch = map(math.radians, view)
    R = rot(-view[1], view[0], 0)          # camera turned by yaw about Y, then pitched
    P = T @ R.T
    if focus is None:
        lo, hi = P.reshape(-1, 3).min(0), P.reshape(-1, 3).max(0)
        c = (lo + hi) / 2
        rad = max(hi - lo) / 2 * 1.05
    else:
        c = np.asarray(focus) @ R.T
        rad = radius
    sc = size / (2 * rad)
    X = (P[..., 0] - c[0]) * sc + size / 2
    Y = size / 2 - (P[..., 1] - c[1]) * sc
    Z = P[..., 2]
    n = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
    n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-9)
    light = np.clip(0.35 + 0.65 * np.abs(n @ np.array([0.3, 0.6, 0.75]) / np.linalg.norm([0.3, 0.6, 0.75])), 0, 1)
    img = np.full((size, size, 3), bg)
    zb = np.full((size, size), -1e9)
    for i in np.argsort(Z.mean(1)):
        xs, ys, zs = X[i], Y[i], Z[i]
        x0, x1 = int(max(0, np.floor(xs.min()))), int(min(size - 1, np.ceil(xs.max())))
        y0, y1 = int(max(0, np.floor(ys.min()))), int(min(size - 1, np.ceil(ys.max())))
        if x1 < x0 or y1 < y0:
            continue
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        d = (ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2])
        if abs(d) < 1e-9:
            continue
        a = ((ys[1] - ys[2]) * (gx - xs[2]) + (xs[2] - xs[1]) * (gy - ys[2])) / d
        b = ((ys[2] - ys[0]) * (gx - xs[2]) + (xs[0] - xs[2]) * (gy - ys[2])) / d
        g = 1 - a - b
        inside = (a >= 0) & (b >= 0) & (g >= 0)
        if not inside.any():
            continue
        z = a * zs[0] + b * zs[1] + g * zs[2]
        sub = zb[y0:y1 + 1, x0:x1 + 1]
        win = inside & (z > sub)
        sub[win] = z[win]
        img[y0:y1 + 1, x0:x1 + 1][win] = C[i] * light[i]
    if want_mask:
        return img, zb > -1e8
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(path)
